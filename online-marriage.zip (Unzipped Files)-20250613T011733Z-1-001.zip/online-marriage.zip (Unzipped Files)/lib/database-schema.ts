// Database schema for document management
// This would be your Prisma schema or similar

export interface DocumentRecord {
  id: string
  bookingId: string
  userId: string
  documentType: "id_partner_1" | "id_partner_2" | "signed_application" | "other"
  fileName: string
  fileSize: number
  mimeType: string
  storageKey: string
  status: "pending" | "approved" | "rejected"
  reviewedBy?: string
  reviewedAt?: Date
  rejectionReason?: string
  uploadedAt: Date
  createdAt: Date
  updatedAt: Date
}

export interface ApplicationProcess {
  id: string
  bookingId: string
  currentStep: number
  totalSteps: number
  stepName: string
  status: "in_progress" | "completed" | "on_hold"
  nextAction?: string
  completedAt?: Date
  createdAt: Date
  updatedAt: Date
}

// SQL Schema Example (PostgreSQL)
const createTables = `
CREATE TABLE document_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id VARCHAR(255) NOT NULL,
  user_id VARCHAR(255) NOT NULL,
  document_type VARCHAR(50) NOT NULL,
  file_name VARCHAR(255) NOT NULL,
  file_size INTEGER NOT NULL,
  mime_type VARCHAR(100) NOT NULL,
  storage_key VARCHAR(500) NOT NULL,
  status VARCHAR(20) DEFAULT 'pending',
  reviewed_by VARCHAR(255),
  reviewed_at TIMESTAMP,
  rejection_reason TEXT,
  uploaded_at TIMESTAMP DEFAULT NOW(),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE application_processes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id VARCHAR(255) NOT NULL UNIQUE,
  current_step INTEGER DEFAULT 1,
  total_steps INTEGER DEFAULT 7,
  step_name VARCHAR(255) NOT NULL,
  status VARCHAR(20) DEFAULT 'in_progress',
  next_action TEXT,
  completed_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
`
