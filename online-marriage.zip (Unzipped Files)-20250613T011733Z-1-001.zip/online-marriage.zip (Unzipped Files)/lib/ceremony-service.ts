import { createZoomMeeting } from "@/lib/zoom-client"

// Process a new booking from Calendly
export async function processNewBooking(calendlyEvent: any) {
  try {
    // Extract ceremony details from Calendly event
    const {
      uri: calendlyEventUri,
      name: customerName,
      email: customerEmail,
      event_type,
      scheduled_event,
      questions_and_answers,
    } = calendlyEvent

    // Parse questions to get participant information
    const partner1 = getPartnerInfo(questions_and_answers, 1)
    const partner2 = getPartnerInfo(questions_and_answers, 2)
    const witnesses = getWitnessInfo(questions_and_answers)

    // Create a Zoom meeting for the ceremony
    const startTime = new Date(scheduled_event.start_time)
    const durationMinutes = getDurationFromEventType(event_type.name)

    const zoomMeeting = await createZoomMeeting({
      topic: `Wedding Ceremony: ${partner1.name} & ${partner2.name}`,
      startTime: scheduled_event.start_time,
      duration: durationMinutes,
      agenda: `Online marriage ceremony for ${partner1.name} & ${partner2.name}`,
      settings: {
        host_video: true,
        participant_video: true,
        join_before_host: false,
        mute_upon_entry: true,
        waiting_room: true,
        meeting_authentication: false,
        auto_recording: "cloud",
      },
    })

    // Create ceremony record in database
    const ceremonyData = {
      calendlyEventUri,
      zoomMeetingId: zoomMeeting.id,
      zoomJoinUrl: zoomMeeting.join_url,
      zoomStartUrl: zoomMeeting.start_url,
      zoomPassword: zoomMeeting.password,
      startTime: scheduled_event.start_time,
      endTime: scheduled_event.end_time,
      status: "SCHEDULED",
      package: getPackageFromEventType(event_type.name),
      participants: [
        {
          name: partner1.name,
          email: partner1.email,
          phone: partner1.phone,
          role: "PARTNER_1",
        },
        {
          name: partner2.name,
          email: partner2.email,
          phone: partner2.phone,
          role: "PARTNER_2",
        },
        ...witnesses.map((witness) => ({
          name: witness.name,
          email: witness.email,
          role: "WITNESS",
        })),
      ],
    }

    // In a real app, you would save this to your database
    // const ceremony = await db.ceremonies.create({ data: ceremonyData })

    // Send confirmation emails to all participants
    await sendCeremonyConfirmationEmails(ceremonyData)

    return {
      success: true,
      ceremony: ceremonyData,
    }
  } catch (error) {
    console.error("Error processing new booking:", error)
    throw error
  }
}

// Helper functions
function getPartnerInfo(questions: any[], partnerNumber: number) {
  // In a real app, you would parse the Calendly questions to extract partner info
  // This is a simplified example
  return {
    name: `Partner ${partnerNumber}`,
    email: `partner${partnerNumber}@example.com`,
    phone: "123-456-7890",
  }
}

function getWitnessInfo(questions: any[]) {
  // In a real app, you would parse the Calendly questions to extract witness info
  // This is a simplified example
  return [
    {
      name: "Witness 1",
      email: "witness1@example.com",
    },
    {
      name: "Witness 2",
      email: "witness2@example.com",
    },
  ]
}

function getDurationFromEventType(eventTypeName: string) {
  // Map event type to duration
  if (eventTypeName.includes("Essential")) return 30
  if (eventTypeName.includes("Premium")) return 45
  if (eventTypeName.includes("Luxury")) return 60
  return 30 // Default
}

function getPackageFromEventType(eventTypeName: string) {
  if (eventTypeName.includes("Essential")) return "ESSENTIAL"
  if (eventTypeName.includes("Premium")) return "PREMIUM"
  if (eventTypeName.includes("Luxury")) return "LUXURY"
  return "PREMIUM" // Default
}

async function sendCeremonyConfirmationEmails(ceremonyData: any) {
  // In a real app, you would send emails to all participants
  // This is a simplified example
  console.log("Sending confirmation emails for ceremony:", ceremonyData.zoomMeetingId)

  // You would use an email service like SendGrid, Mailgun, etc.
  // Example:
  // await sendgrid.send({
  //   to: participant.email,
  //   from: "ceremonies@onlinemarriagesnow.com",
  //   subject: "Your Upcoming Online Marriage Ceremony",
  //   text: `Your ceremony is scheduled for ${ceremonyData.startTime}. Join URL: ${ceremonyData.zoomJoinUrl}`,
  //   html: `<p>Your ceremony is scheduled for ${ceremonyData.startTime}.</p><p><a href="${ceremonyData.zoomJoinUrl}">Click here to join</a></p>`,
  // })
}
