interface PendingBooking {
  id: string
  calendlyEventUri: string
  createdAt: Date
  expiresAt: Date
  customerEmail: string
  customerName: string
  package: string
  status: "PENDING_PAYMENT" | "PAID" | "EXPIRED" | "CANCELLED"
}

// In-memory store for demo - in production, use a database
const pendingBookings = new Map<string, PendingBooking>()

export function createPendingBooking(data: {
  bookingId: string
  calendlyEventUri: string
  customerEmail: string
  customerName: string
  package: string
}) {
  const now = new Date()
  const expiresAt = new Date(now.getTime() + 30 * 60 * 1000) // 30 minutes

  const pendingBooking: PendingBooking = {
    id: data.bookingId,
    calendlyEventUri: data.calendlyEventUri,
    createdAt: now,
    expiresAt,
    customerEmail: data.customerEmail,
    customerName: data.customerName,
    package: data.package,
    status: "PENDING_PAYMENT",
  }

  pendingBookings.set(data.bookingId, pendingBooking)

  // Schedule auto-cancellation
  setTimeout(
    () => {
      autoCancelExpiredBooking(data.bookingId)
    },
    30 * 60 * 1000,
  ) // 30 minutes

  return pendingBooking
}

export function markBookingAsPaid(bookingId: string) {
  const booking = pendingBookings.get(bookingId)
  if (booking) {
    booking.status = "PAID"
    pendingBookings.set(bookingId, booking)
  }
}

export function getPendingBooking(bookingId: string): PendingBooking | undefined {
  return pendingBookings.get(bookingId)
}

async function autoCancelExpiredBooking(bookingId: string) {
  const booking = pendingBookings.get(bookingId)

  if (!booking || booking.status !== "PENDING_PAYMENT") {
    return // Already paid or cancelled
  }

  try {
    // Cancel the Calendly event using the API
    await cancelCalendlyEvent(booking.calendlyEventUri)

    // Update booking status
    booking.status = "EXPIRED"
    pendingBookings.set(bookingId, booking)

    // Send cancellation email to customer
    await sendBookingExpiredEmail(booking)

    console.log(`Auto-cancelled expired booking: ${bookingId}`)
  } catch (error) {
    console.error(`Failed to auto-cancel booking ${bookingId}:`, error)
  }
}

async function cancelCalendlyEvent(eventUri: string) {
  const apiToken = process.env.CALENDLY_API_TOKEN

  if (!apiToken) {
    throw new Error("Calendly API token not configured")
  }

  try {
    // Extract the event UUID from the URI
    const eventUuid = eventUri.split("/").pop()

    const response = await fetch(`https://api.calendly.com/scheduled_events/${eventUuid}/cancellation`, {
      method: "POST",
      headers: {
        Authorization: apiToken,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        reason: "Payment not completed within the required time limit",
      }),
    })

    if (!response.ok) {
      const errorText = await response.text()
      throw new Error(`Calendly cancellation failed: ${response.status} - ${errorText}`)
    }

    console.log(`Successfully cancelled Calendly event: ${eventUri}`)
    return await response.json()
  } catch (error) {
    console.error(`Failed to cancel Calendly event ${eventUri}:`, error)
    throw error
  }
}

async function sendBookingExpiredEmail(booking: PendingBooking) {
  // Send email notification about expired booking
  console.log(`Sending expiration email to: ${booking.customerEmail}`)

  // In production, integrate with your email service:
  try {
    // You can integrate with your existing email service here
    // await emailService.send({
    //   to: booking.customerEmail,
    //   subject: 'Booking Expired - Please Reschedule Your Ceremony',
    //   template: 'booking-expired',
    //   data: {
    //     customerName: booking.customerName,
    //     package: booking.package,
    //     rebookUrl: `${process.env.NEXT_PUBLIC_BASE_URL}/booking`
    //   }
    // })

    console.log(`Expiration email would be sent to ${booking.customerEmail}`)
  } catch (error) {
    console.error("Failed to send expiration email:", error)
  }
}
