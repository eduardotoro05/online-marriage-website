// Simple document service for browser environment
export interface SimpleDocumentUpload {
  fileName: string
  fileType: string
  fileSize: number
  bookingId: string
  customerName: string
  customerEmail: string
  documentType: string
}

export class SimpleDocumentService {
  // Get downloadable documents (static for MVP)
  static getDownloadableDocuments() {
    return [
      {
        id: "doc-1",
        name: "Utah Marriage Application",
        description: "Official application form required by Utah County",
        url: "/documents/utah-marriage-application.pdf",
      },
      {
        id: "doc-2",
        name: "ID Requirements",
        description: "Instructions for acceptable identification documents",
        url: "/documents/id-requirements.pdf",
      },
      {
        id: "doc-3",
        name: "Marriage Certificate Sample",
        description: "Example of what your certificate will look like",
        url: "/documents/certificate-sample.pdf",
      },
    ]
  }
}
