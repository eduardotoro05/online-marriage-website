// Helper functions for Calendly integration using direct HTTP requests

export function loadCalendlyScript(): Promise<void> {
  return new Promise((resolve) => {
    // Check if script is already loaded
    if (document.getElementById("calendly-script")) {
      resolve()
      return
    }

    // Create script element
    const script = document.createElement("script")
    script.id = "calendly-script"
    script.src = "https://assets.calendly.com/assets/external/widget.js"
    script.async = true
    script.onload = () => resolve()

    // Add script to document
    document.head.appendChild(script)
  })
}

interface CalendlyWidgetOptions {
  url: string
  parentElement: HTMLElement
  prefill?: {
    name?: string
    email?: string
    customAnswers?: Record<string, string>
  }
  utm?: Record<string, string>
}

export function initCalendlyWidget({ url, parentElement, prefill, utm }: CalendlyWidgetOptions): void {
  if (typeof window !== "undefined" && window.Calendly) {
    window.Calendly.initInlineWidget({
      url,
      parentElement,
      prefill,
      utm,
    })
  }
}

// Calendly API functions using direct HTTP requests
export async function getCalendlyEvent(eventUri: string) {
  const apiKey = process.env.CALENDLY_API_KEY

  if (!apiKey) {
    throw new Error("Calendly API key not configured")
  }

  const response = await fetch(`https://api.calendly.com/scheduled_events/${eventUri}`, {
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
  })

  if (!response.ok) {
    throw new Error(`Failed to get Calendly event: ${response.statusText}`)
  }

  return response.json()
}

export async function cancelCalendlyEvent(eventUri: string, reason?: string) {
  const apiKey = process.env.CALENDLY_API_KEY

  if (!apiKey) {
    throw new Error("Calendly API key not configured")
  }

  const response = await fetch(`https://api.calendly.com/scheduled_events/${eventUri}/cancellation`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      reason: reason || "Canceled by user",
    }),
  })

  if (!response.ok) {
    throw new Error(`Failed to cancel Calendly event: ${response.statusText}`)
  }

  return response.json()
}

// Add TypeScript definitions for Calendly
declare global {
  interface Window {
    Calendly: {
      initInlineWidget: (options: {
        url: string
        parentElement: HTMLElement
        prefill?: {
          name?: string
          email?: string
          customAnswers?: Record<string, string>
        }
        utm?: Record<string, string>
      }) => void
    }
  }
}
