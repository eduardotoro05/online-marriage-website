import sgMail from "@sendgrid/mail"

// Initialize SendGrid
if (process.env.SENDGRID_API_KEY) {
  sgMail.setApiKey(process.env.SENDGRID_API_KEY)
}

interface BookingData {
  id: string
  partnerOne: {
    firstName: string
    lastName: string
    email: string
    phone: string
  }
  partnerTwo: {
    firstName: string
    lastName: string
    email: string
    phone: string
  }
  package: {
    name: string
    price: number
  }
  ceremonyDate: string
  ceremonyTime: string
  paymentIntentId?: string
  promoCode?: string
  finalAmount: number
  zoomMeeting?: {
    id: string
    join_url: string
    password: string
  }
  status: string
  createdAt: string
}

export async function sendBookingConfirmation(bookingData: BookingData) {
  console.log("=== EMAIL SERVICE CALLED ===")
  console.log("Full booking data received:", JSON.stringify(bookingData, null, 2))
  console.log("Partner One Email:", bookingData.partnerOne?.email)
  console.log("Partner Two Email:", bookingData.partnerTwo?.email)

  if (!process.env.SENDGRID_API_KEY) {
    console.log("SendGrid API key not configured, skipping email")
    return
  }

  const {
    partnerOne,
    partnerTwo,
    package: selectedPackage,
    ceremonyDate,
    ceremonyTime,
    finalAmount,
    promoCode,
    zoomMeeting,
    id,
  } = bookingData

  // Format the ceremony date and time
  const ceremonyDateTime = new Date(`${ceremonyDate}T${ceremonyTime}`)
  const formattedDate = ceremonyDateTime.toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  })
  const formattedTime = ceremonyDateTime.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  })

  // Create email content
  const emailSubject = `Your Wedding Ceremony is Confirmed! - ${partnerOne.firstName} & ${partnerTwo.firstName}`

  const emailHtml = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Wedding Ceremony Confirmation</title>
      <style>
        /* Base styles */
        body { 
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; 
          line-height: 1.6; 
          color: #333; 
          margin: 0; 
          padding: 0;
          background-color: #f9f9fb;
        }
        .container {
          max-width: 600px;
          margin: 0 auto;
          background-color: #ffffff;
          border-radius: 12px;
          overflow: hidden;
          box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }
        /* Header */
        .header { 
          background: linear-gradient(135deg, #ec4899, #f472b6); 
          color: white; 
          padding: 30px 20px; 
          text-align: center;
        }
        .header h1 {
          margin: 0;
          font-size: 28px;
          font-weight: 700;
        }
        .header h2 {
          margin: 10px 0 0;
          font-size: 20px;
          font-weight: 500;
          opacity: 0.9;
        }
        .logo {
          margin-bottom: 15px;
        }
        /* Content */
        .content { 
          padding: 30px 25px;
        }
        /* Sections */
        .section {
          margin-bottom: 25px;
          border-radius: 8px;
          padding: 20px;
        }
        .section h3 {
          margin-top: 0;
          font-size: 18px;
          font-weight: 600;
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .section h3 span {
          font-size: 20px;
        }
        /* Booking details */
        .booking-details { 
          background-color: #fdf2f8; 
          border-left: 4px solid #ec4899;
        }
        /* Zoom section */
        .zoom-section { 
          background-color: #eff6ff; 
          border-left: 4px solid #3b82f6;
        }
        /* Next steps */
        .next-steps {
          background-color: #f0fdf4;
          border-left: 4px solid #10b981;
        }
        /* Support */
        .support {
          background-color: #fef3c7;
          border-left: 4px solid #f59e0b;
        }
        /* Elements */
        .button { 
          display: inline-block; 
          background: #ec4899; 
          color: white !important; 
          padding: 12px 24px; 
          text-decoration: none; 
          border-radius: 6px; 
          font-weight: 600;
          margin: 10px 0;
          text-align: center;
        }
        .button.zoom {
          background: #3b82f6;
        }
        .price { 
          font-size: 24px; 
          font-weight: bold; 
          color: #ec4899;
        }
        .free-badge { 
          background: #10b981; 
          color: white; 
          padding: 4px 12px; 
          border-radius: 20px; 
          font-size: 14px; 
          font-weight: bold;
          display: inline-block;
        }
        .booking-id {
          font-family: monospace;
          background: #f3f4f6;
          padding: 3px 6px;
          border-radius: 4px;
          font-size: 14px;
        }
        .detail-row {
          display: flex;
          justify-content: space-between;
          margin-bottom: 8px;
          flex-wrap: wrap;
        }
        .detail-label {
          font-weight: 600;
          min-width: 120px;
        }
        .detail-value {
          text-align: right;
          flex: 1;
        }
        .divider {
          height: 1px;
          background-color: #e5e7eb;
          margin: 15px 0;
        }
        .step {
          display: flex;
          gap: 12px;
          margin-bottom: 12px;
        }
        .step-number {
          background-color: #10b981;
          color: white;
          width: 24px;
          height: 24px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: bold;
          flex-shrink: 0;
        }
        .step-content {
          flex: 1;
        }
        /* Footer */
        .footer { 
          background: #f9fafb; 
          padding: 20px; 
          text-align: center;
          color: #6b7280;
          font-size: 14px;
          border-top: 1px solid #e5e7eb;
        }
        .social-links {
          margin: 15px 0;
        }
        .social-link {
          display: inline-block;
          margin: 0 8px;
          color: #6b7280;
          text-decoration: none;
        }
        a {
          color: #ec4899;
          text-decoration: none;
        }
        @media (max-width: 600px) {
          .container {
            border-radius: 0;
          }
          .detail-row {
            flex-direction: column;
            align-items: flex-start;
          }
          .detail-value {
            text-align: left;
            margin-top: 2px;
          }
        }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <div class="logo">💍 OnlineMarriagesNow</div>
          <h1>Your Wedding is Confirmed!</h1>
          <h2>${partnerOne.firstName} & ${partnerTwo.firstName}</h2>
        </div>
        
        <div class="content">
          <p>Congratulations on your upcoming wedding ceremony! We're honored to be part of your special day.</p>
          
          <div class="section booking-details">
            <h3><span>📋</span> Ceremony Details</h3>
            
            <div class="detail-row">
              <div class="detail-label">Booking ID:</div>
              <div class="detail-value"><span class="booking-id">${id}</span></div>
            </div>
            
            <div class="detail-row">
              <div class="detail-label">Couple:</div>
              <div class="detail-value">${partnerOne.firstName} ${partnerOne.lastName} & ${partnerTwo.firstName} ${partnerTwo.lastName}</div>
            </div>
            
            <div class="detail-row">
              <div class="detail-label">Package:</div>
              <div class="detail-value">${selectedPackage.name}</div>
            </div>
            
            <div class="detail-row">
              <div class="detail-label">Date:</div>
              <div class="detail-value">${formattedDate}</div>
            </div>
            
            <div class="detail-row">
              <div class="detail-label">Time:</div>
              <div class="detail-value">${formattedTime}</div>
            </div>
            
            <div class="divider"></div>
            
            <div class="detail-row">
              <div class="detail-label">Package Price:</div>
              <div class="detail-value">$${selectedPackage.price.toFixed(2)}</div>
            </div>
            
            ${
              promoCode
                ? `
            <div class="detail-row">
              <div class="detail-label">Promo Code:</div>
              <div class="detail-value">${promoCode}</div>
            </div>
            
            <div class="detail-row">
              <div class="detail-label">Discount:</div>
              <div class="detail-value">-$${(selectedPackage.price - finalAmount).toFixed(2)}</div>
            </div>
            `
                : ""
            }
            
            <div class="detail-row">
              <div class="detail-label">Total:</div>
              <div class="detail-value">
                ${
                  finalAmount === 0
                    ? '<span class="free-badge">FREE</span>'
                    : `<span class="price">$${finalAmount.toFixed(2)}</span>`
                }
              </div>
            </div>
          </div>

          ${
            zoomMeeting
              ? `
          <div class="section zoom-section">
            <h3><span>💻</span> Virtual Ceremony Access</h3>
            <p>Your ceremony will be conducted via Zoom. Here are your meeting details:</p>
            
            <div class="detail-row">
              <div class="detail-label">Meeting ID:</div>
              <div class="detail-value">${zoomMeeting.id}</div>
            </div>
            
            <div class="detail-row">
              <div class="detail-label">Password:</div>
              <div class="detail-value">${zoomMeeting.password}</div>
            </div>
            
            <a href="${zoomMeeting.join_url}" class="button zoom">Join Your Ceremony</a>
            <p><small>You can join the meeting by clicking the button above or copying the link into your browser.</small></p>
          </div>
          `
              : ""
          }

          <div class="section next-steps">
            <h3><span>📝</span> Next Steps</h3>
            
            <div class="step">
              <div class="step-number">1</div>
              <div class="step-content">
                <strong>Mark your calendar</strong>
                <p>Add your ceremony to your calendar so you don't forget the date and time.</p>
              </div>
            </div>
            
            <div class="step">
              <div class="step-number">2</div>
              <div class="step-content">
                <strong>Prepare your vows</strong>
                <p>Consider writing personal vows to share during your ceremony.</p>
              </div>
            </div>
            
            <div class="step">
              <div class="step-number">3</div>
              <div class="step-content">
                <strong>Test your equipment</strong>
                <p>Make sure your camera, microphone, and internet connection work properly before the ceremony.</p>
              </div>
            </div>
            
            <div class="step">
              <div class="step-number">4</div>
              <div class="step-content">
                <strong>Join early</strong>
                <p>Log in to your ceremony 5-10 minutes early to ensure everything is working properly.</p>
              </div>
            </div>
          </div>

          <div class="section support">
            <h3><span>📞</span> Need Help?</h3>
            <p>If you have any questions or need to make changes to your booking, please contact us:</p>
            <p>Email: <a href="mailto:support@onlinemarriagesnow.com">support@onlinemarriagesnow.com</a></p>
            <p>Please include your Booking ID: <span class="booking-id">${id}</span></p>
          </div>

          <p>We're honored to be part of your special day and look forward to officiating your wedding ceremony!</p>
          
          <p>With warm regards,<br>
          <strong>The OnlineMarriagesNow Team</strong></p>
        </div>
        
        <div class="footer">
          <p>© 2024 OnlineMarriagesNow. All rights reserved.</p>
          <p>Legal online marriages in the United States</p>
          <div class="social-links">
            <a href="#" class="social-link">Facebook</a>
            <a href="#" class="social-link">Instagram</a>
            <a href="#" class="social-link">Twitter</a>
          </div>
          <p><small>This email was sent to you because you booked a ceremony with OnlineMarriagesNow.</small></p>
        </div>
      </div>
    </body>
    </html>
  `

  const emailText = `
WEDDING CEREMONY CONFIRMATION
${partnerOne.firstName} & ${partnerTwo.firstName}

Congratulations on your upcoming wedding ceremony! We're honored to be part of your special day.

CEREMONY DETAILS
----------------
Booking ID: ${id}
Couple: ${partnerOne.firstName} ${partnerOne.lastName} & ${partnerTwo.firstName} ${partnerTwo.lastName}
Package: ${selectedPackage.name}
Date: ${formattedDate}
Time: ${formattedTime}

Package Price: $${selectedPackage.price.toFixed(2)}
${
  promoCode
    ? `Promo Code: ${promoCode}
Discount: -$${(selectedPackage.price - finalAmount).toFixed(2)}`
    : ""
}
Total: ${finalAmount === 0 ? "FREE" : `$${finalAmount.toFixed(2)}`}

${
  zoomMeeting
    ? `
VIRTUAL CEREMONY ACCESS
----------------------
Your ceremony will be conducted via Zoom. Here are your meeting details:

Meeting ID: ${zoomMeeting.id}
Password: ${zoomMeeting.password}
Join URL: ${zoomMeeting.join_url}
`
    : ""
}

NEXT STEPS
----------
1. Mark your calendar - Add your ceremony to your calendar
2. Prepare your vows - Consider writing personal vows to share
3. Test your equipment - Check your camera, microphone, and internet
4. Join early - Log in 5-10 minutes before the ceremony

NEED HELP?
----------
Email: support@onlinemarriagesnow.com
Please include your Booking ID: ${id}

We're honored to be part of your special day!

The OnlineMarriagesNow Team

© 2024 OnlineMarriagesNow. All rights reserved.
Legal online marriages in the United States
  `

  // Send emails to both partners
  const emails = [
    {
      to: partnerOne.email,
      from: {
        email: "noreply@onlinemarriagesnow.com",
        name: "OnlineMarriagesNow",
      },
      replyTo: "support@onlinemarriagesnow.com",
      subject: emailSubject,
      text: emailText,
      html: emailHtml,
    },
    {
      to: partnerTwo.email,
      from: {
        email: "noreply@onlinemarriagesnow.com",
        name: "OnlineMarriagesNow",
      },
      replyTo: "support@onlinemarriagesnow.com",
      subject: emailSubject,
      text: emailText,
      html: emailHtml,
    },
  ]

  try {
    await sgMail.send(emails)
    console.log("Booking confirmation emails sent successfully")
  } catch (error) {
    console.error("Error sending booking confirmation emails:", error)
    throw error
  }
}
