// Simple document tracking for MVP
export interface DocumentRecord {
  id: string
  fileName: string
  fileType: string
  fileSize: number
  documentType: string
  bookingId: string
  customerName: string
  customerEmail: string
  uploadedAt: string
  status: "uploaded" | "reviewed" | "approved" | "rejected"
}

export interface RequiredDocument {
  type: string
  name: string
  description: string
  required: boolean
  uploaded: boolean
  uploadedAt?: string
  fileName?: string
}

export class DocumentTracker {
  // Get required documents for a booking
  static getRequiredDocuments(bookingId: string): RequiredDocument[] {
    // For MVP, we'll use localStorage to track uploads
    const uploadedDocs = this.getUploadedDocuments(bookingId)

    const requiredDocs: RequiredDocument[] = [
      {
        type: "id_person1",
        name: "Person 1 - Government ID",
        description: "Valid government-issued photo ID (driver's license, passport, etc.)",
        required: true,
        uploaded: uploadedDocs.some((doc) => doc.documentType === "id_person1"),
        ...this.getDocumentDetails(uploadedDocs, "id_person1"),
      },
      {
        type: "id_person2",
        name: "Person 2 - Government ID",
        description: "Valid government-issued photo ID (driver's license, passport, etc.)",
        required: true,
        uploaded: uploadedDocs.some((doc) => doc.documentType === "id_person2"),
        ...this.getDocumentDetails(uploadedDocs, "id_person2"),
      },
      {
        type: "application",
        name: "Signed Marriage Application",
        description: "Completed and signed Utah marriage license application",
        required: true,
        uploaded: uploadedDocs.some((doc) => doc.documentType === "application"),
        ...this.getDocumentDetails(uploadedDocs, "application"),
      },
      {
        type: "witness_ids",
        name: "Witness IDs (if applicable)",
        description: "IDs for witnesses if you don't have your own",
        required: false,
        uploaded: uploadedDocs.some((doc) => doc.documentType === "witness_ids"),
        ...this.getDocumentDetails(uploadedDocs, "witness_ids"),
      },
    ]

    return requiredDocs
  }

  // Store uploaded document record
  static storeUploadedDocument(document: DocumentRecord): void {
    const key = `documents_${document.bookingId}`
    const existing = localStorage.getItem(key)
    const documents: DocumentRecord[] = existing ? JSON.parse(existing) : []

    documents.push(document)
    localStorage.setItem(key, JSON.stringify(documents))
  }

  // Get uploaded documents for a booking
  static getUploadedDocuments(bookingId: string): DocumentRecord[] {
    if (typeof window === "undefined") return [] // Server-side safety

    const key = `documents_${bookingId}`
    const stored = localStorage.getItem(key)
    return stored ? JSON.parse(stored) : []
  }

  // Helper to get document details
  private static getDocumentDetails(uploadedDocs: DocumentRecord[], docType: string) {
    const doc = uploadedDocs.find((d) => d.documentType === docType)
    if (doc) {
      return {
        uploadedAt: doc.uploadedAt,
        fileName: doc.fileName,
      }
    }
    return {}
  }

  // Calculate completion percentage
  static getCompletionPercentage(bookingId: string): number {
    const required = this.getRequiredDocuments(bookingId)
    const requiredDocs = required.filter((doc) => doc.required)
    const uploadedRequired = requiredDocs.filter((doc) => doc.uploaded)

    return requiredDocs.length > 0 ? Math.round((uploadedRequired.length / requiredDocs.length) * 100) : 0
  }
}
