// This service would connect to your storage solution in production
// For now, we'll simulate document operations

export type DocumentStatus = "pending" | "approved" | "rejected"

export interface Document {
  id: string
  name: string
  type: "id" | "application" | "certificate" | "other"
  status: DocumentStatus
  uploadedBy?: string
  uploadedAt?: string
  url?: string
  notes?: string
}

export interface ApplicationProcess {
  id: string
  step: number
  totalSteps: number
  currentStepName: string
  isComplete: boolean
  nextAction?: string
  documents: Document[]
}

// Mock data for demonstration
const mockDocuments: Document[] = [
  {
    id: "doc-1",
    name: "Utah Marriage Application",
    type: "application",
    status: "approved",
    url: "/documents/utah-marriage-application.pdf",
  },
  {
    id: "doc-2",
    name: "Marriage Certificate Sample",
    type: "certificate",
    status: "approved",
    url: "/documents/marriage-certificate-sample.pdf",
  },
  {
    id: "doc-3",
    name: "ID Upload Instructions",
    type: "other",
    status: "approved",
    url: "/documents/id-upload-instructions.pdf",
  },
]

// Mock application process
export const getApplicationProcess = async (userId: string): Promise<ApplicationProcess> => {
  // In production, fetch from your database
  return {
    id: "process-1",
    step: 2,
    totalSteps: 7,
    currentStepName: "Marriage License Application",
    isComplete: false,
    nextAction: "Upload your signed application form",
    documents: mockDocuments,
  }
}

export const getDownloadableDocuments = async (): Promise<Document[]> => {
  // In production, fetch from your database or storage
  return mockDocuments.filter((doc) => doc.type === "application" || doc.type === "other")
}

export const getUserDocuments = async (userId: string): Promise<Document[]> => {
  // In production, fetch from your database
  // For now, return empty array as the user hasn't uploaded anything yet
  return []
}

export const uploadDocument = async (file: File, type: Document["type"], userId: string): Promise<Document> => {
  // In production, upload to your storage solution and save metadata to database

  // Mock response
  const newDoc: Document = {
    id: `doc-${Date.now()}`,
    name: file.name,
    type,
    status: "pending",
    uploadedBy: userId,
    uploadedAt: new Date().toISOString(),
    // In production, this would be the actual URL after upload
    url: URL.createObjectURL(file),
  }

  return newDoc
}
