// Service for managing Utah-specific documents
export class UtahDocumentService {
  // URLs to official Utah documents
  private static readonly UTAH_MARRIAGE_APPLICATION_URL =
    "https://www.utahcounty.gov/dept/clerkaud/documents/MarriageLicenseApplication.pdf"

  // Document templates you'll need to create/obtain
  static readonly REQUIRED_DOCUMENTS = {
    marriageApplication: {
      name: "Utah Marriage License Application",
      description: "Official application form required by Utah County",
      url: "/documents/utah-marriage-application.pdf",
      source: "Utah County Clerk's Office",
    },
    idInstructions: {
      name: "ID Upload Instructions",
      description: "Requirements for acceptable identification documents",
      url: "/documents/id-upload-instructions.pdf",
      source: "Created by OnlineMarriagesNow",
    },
    certificateSample: {
      name: "Marriage Certificate Sample",
      description: "Example of what your marriage certificate will look like",
      url: "/documents/marriage-certificate-sample.pdf",
      source: "Utah Vital Records Office",
    },
  }

  // Method to sync latest documents from Utah
  static async syncUtahDocuments() {
    // Periodically download latest versions from Utah County
    // This ensures you always have current forms
  }

  // Validate document requirements
  static validateDocumentRequirements(documentType: string, file: File): string[] {
    const errors: string[] = []

    switch (documentType) {
      case "id":
        if (!["image/jpeg", "image/png", "application/pdf"].includes(file.type)) {
          errors.push("ID must be JPEG, PNG, or PDF format")
        }
        if (file.size > 5 * 1024 * 1024) {
          errors.push("ID file must be under 5MB")
        }
        break
      case "application":
        if (file.type !== "application/pdf") {
          errors.push("Application must be PDF format")
        }
        break
    }

    return errors
  }
}
