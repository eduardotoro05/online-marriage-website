"use client"

import Link from "next/link"
import Image from "next/image"
import { ArrowRight, Check, Heart, Plus } from "lucide-react"

import { Button } from "@/components/ui/button"
import { useEffect } from "react"

export default function LandingPage() {
  // Add this right after the component declaration
  useEffect(() => {
    // Clean up any stray Calendly widgets on the landing page
    const calendlyWidgets = document.querySelectorAll("[data-calendly-widget], .calendly-inline-widget")
    calendlyWidgets.forEach((widget) => widget.remove())

    // Also remove any Calendly scripts that might be interfering
    const calendlyScripts = document.querySelectorAll('script[src*="calendly"]')
    calendlyScripts.forEach((script) => {
      if (script.id !== "calendly-widget-script") {
        script.remove()
      }
    })
  }, [])
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="/how-it-works" className="text-sm font-medium">
              How It Works
            </Link>
            <Link href="/faq" className="text-sm font-medium">
              FAQ
            </Link>
            <Link href="/pricing" className="text-sm font-medium">
              Pricing
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/booking">
              <Button>Get Married Now</Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-rose-50 to-white">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 xl:grid-cols-2">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                    Legal Online Marriages in the United States
                  </h1>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl">
                    Say "I do" from anywhere. Our legally-recognized online ceremonies make marriage accessible,
                    affordable, and meaningful.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Link href="/booking">
                    <Button size="lg" className="bg-rose-600 hover:bg-rose-700">
                      Book Your Ceremony - $299
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                  <Link href="/how-it-works">
                    <Button size="lg" variant="outline">
                      Learn How It Works
                    </Button>
                  </Link>
                </div>
                <div className="flex items-center gap-4 text-sm">
                  <div className="flex items-center gap-1">
                    <Check className="h-4 w-4 text-green-500" />
                    <span>100% Legal</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Check className="h-4 w-4 text-green-500" />
                    <span>Licensed Officiants</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Check className="h-4 w-4 text-green-500" />
                    <span>Same-Day Available</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <Image
                  src="/images/hero-couple-wedding.png"
                  width={600}
                  height={400}
                  alt="Happy couple getting married online"
                  className="rounded-lg object-cover shadow-lg"
                  priority
                />
              </div>
            </div>
          </div>
        </section>

        {/* Pricing Section */}
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight">Simple, Transparent Pricing</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  One price, everything included. Add only what you need.
                </p>
              </div>
            </div>

            <div className="mx-auto max-w-4xl mt-12">
              {/* Main Package */}
              <div className="text-center mb-8">
                <div className="inline-block rounded-lg border-2 border-rose-200 bg-rose-50 p-8 shadow-lg">
                  <h3 className="text-2xl font-bold mb-2">Online Marriage Ceremony</h3>
                  <div className="mb-4">
                    <span className="text-5xl font-bold text-rose-600">$299</span>
                    <span className="text-muted-foreground ml-2">one-time</span>
                  </div>
                  <p className="text-muted-foreground mb-6">Everything you need for a legal marriage ceremony</p>

                  <div className="grid gap-3 text-left max-w-md mx-auto mb-6">
                    <div className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                      <span>Licensed officiant</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                      <span>Legal marriage certificate</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                      <span>30-minute ceremony</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                      <span>Invite unlimited guests</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                      <span>Choose your own vows or use ours</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                      <span>Ceremony recording</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                      <span>Digital certificate copy</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                      <span>Email support</span>
                    </div>
                  </div>

                  <Link href="/booking">
                    <Button size="lg" className="bg-rose-600 hover:bg-rose-700">
                      Book Your Ceremony
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </div>

              {/* Add-ons */}
              <div className="mt-12">
                <h3 className="text-2xl font-bold text-center mb-8">Optional Add-ons</h3>
                <div className="grid gap-6 md:grid-cols-3">
                  <div className="rounded-lg border p-6 text-center">
                    <div className="mb-4">
                      <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-blue-100 mb-3">
                        <Plus className="h-6 w-6 text-blue-600" />
                      </div>
                      <h4 className="text-lg font-semibold">Same-Day Ceremony</h4>
                    </div>
                    <div className="mb-4">
                      <span className="text-2xl font-bold">+$200</span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Get married today! Perfect for urgent situations or when you can't wait.
                    </p>
                    <div className="text-xs text-muted-foreground">Subject to officiant availability</div>
                  </div>

                  <div className="rounded-lg border p-6 text-center">
                    <div className="mb-4">
                      <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-green-100 mb-3">
                        <Plus className="h-6 w-6 text-green-600" />
                      </div>
                      <h4 className="text-lg font-semibold">Witnesses Provided</h4>
                    </div>
                    <div className="mb-4">
                      <span className="text-2xl font-bold">+$25</span>
                      <span className="text-sm text-muted-foreground"> each</span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      We'll provide professional witnesses if your state requires them or you need extras.
                    </p>
                    <div className="text-xs text-muted-foreground">Most states require 1-2 witnesses</div>
                  </div>

                  <div className="rounded-lg border p-6 text-center">
                    <div className="mb-4">
                      <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-purple-100 mb-3">
                        <Plus className="h-6 w-6 text-purple-600" />
                      </div>
                      <h4 className="text-lg font-semibold">Apostille Stamp</h4>
                    </div>
                    <div className="mb-4">
                      <span className="text-2xl font-bold">+$150</span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      International authentication for your marriage certificate for use abroad.
                    </p>
                    <div className="text-xs text-muted-foreground">Required for international recognition</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <div className="inline-block rounded-lg bg-rose-100 px-3 py-1 text-sm text-rose-700">How It Works</div>
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight">Simple, Legal, and Meaningful</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Our online marriage service is designed to be straightforward while ensuring your ceremony is both
                  legally valid and personally meaningful.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-3 lg:gap-12">
              <div className="flex flex-col items-center space-y-4 text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-rose-100">
                  <span className="text-2xl font-bold text-rose-700">1</span>
                </div>
                <h3 className="text-xl font-bold">Book & Register</h3>
                <p className="text-muted-foreground">
                  Choose your date, add any extras you need, and complete your registration with valid identification.
                </p>
              </div>
              <div className="flex flex-col items-center space-y-4 text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-rose-100">
                  <span className="text-2xl font-bold text-rose-700">2</span>
                </div>
                <h3 className="text-xl font-bold">Virtual Ceremony</h3>
                <p className="text-muted-foreground">
                  Connect via our secure video platform with your licensed officiant and witnesses (if required by your
                  state).
                </p>
              </div>
              <div className="flex flex-col items-center space-y-4 text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-rose-100">
                  <span className="text-2xl font-bold text-rose-700">3</span>
                </div>
                <h3 className="text-xl font-bold">Official Documentation</h3>
                <p className="text-muted-foreground">
                  We handle all the paperwork. Your official marriage certificate will be mailed to you within days.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32 bg-slate-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight">What Our Newlyweds Say</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Thousands of couples have trusted us with their special day.
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl gap-6 py-12 lg:grid-cols-3 lg:gap-12">
              {testimonials.map((testimonial, index) => (
                <div
                  key={index}
                  className="flex flex-col justify-between space-y-4 rounded-lg border bg-background p-6 shadow-sm"
                >
                  <div className="space-y-2">
                    <p className="text-muted-foreground">{testimonial.content}</p>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="rounded-full bg-slate-100 p-1">
                      <div className="h-10 w-10 rounded-full bg-rose-100 flex items-center justify-center">
                        <span className="text-sm font-medium text-rose-700">
                          {testimonial.name.split(" ")[0][0]}
                          {testimonial.name.includes("&") ? testimonial.name.split("&")[1].trim()[0] : ""}
                        </span>
                      </div>
                    </div>
                    <div>
                      <p className="text-sm font-medium">{testimonial.name}</p>
                      <p className="text-xs text-muted-foreground">{testimonial.location}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex justify-center">
              <Link href="/testimonials">
                <Button variant="outline">Read More Testimonials</Button>
              </Link>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight">Ready to Say "I Do"?</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Start your journey together with a ceremony that's as unique as your love story.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Link href="/pricing">
                  <Button size="lg" variant="outline">
                    View Pricing
                  </Button>
                </Link>
                <Link href="/booking">
                  <Button size="lg" className="bg-rose-600 hover:bg-rose-700">
                    Book Your Ceremony - $299
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t bg-slate-50 py-6 md:py-12">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <div className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </div>
          <p className="text-center text-sm text-muted-foreground md:text-left">
            © {new Date().getFullYear()} OnlineMarriagesNow. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Link href="/terms" className="text-sm text-muted-foreground hover:underline">
              Terms
            </Link>
            <Link href="/privacy" className="text-sm text-muted-foreground hover:underline">
              Privacy
            </Link>
            <Link href="/contact" className="text-sm text-muted-foreground hover:underline">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

const testimonials = [
  {
    content:
      "We were able to get married despite being in different states for work. The process was seamless and our ceremony was beautiful!",
    name: "Sarah & Michael",
    location: "California & New York",
  },
  {
    content:
      "As a military couple, this service was a blessing. We didn't have to wait until we were stationed together to start our lives.",
    name: "James & Rebecca",
    location: "Texas & Overseas",
  },
  {
    content:
      "Our families from across the country could all attend our ceremony virtually. It was more inclusive than we ever imagined.",
    name: "David & Jennifer",
    location: "Florida",
  },
]
