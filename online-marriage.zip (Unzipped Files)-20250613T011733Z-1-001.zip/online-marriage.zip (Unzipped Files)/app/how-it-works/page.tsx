import Link from "next/link"
import { ArrowRight, Check, Heart, Clock, Shield, Users, FileText, Video, Award } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

export default function HowItWorksPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="/how-it-works" className="text-sm font-medium text-rose-600">
              How It Works
            </Link>
            <Link href="/faq" className="text-sm font-medium">
              FAQ
            </Link>
            <Link href="/pricing" className="text-sm font-medium">
              Pricing
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/booking">
              <Button>Get Married Now</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-rose-50 to-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl/none">
                  How Online Marriage Works
                </h1>
                <p className="mx-auto max-w-[700px] text-muted-foreground md:text-xl">
                  Get legally married online in just 3 simple steps. Our process is designed to be straightforward,
                  secure, and legally compliant in all participating states.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Link href="/booking">
                  <Button size="lg" className="bg-rose-600 hover:bg-rose-700">
                    Start Your Marriage
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
                <Link href="/pricing">
                  <Button size="lg" variant="outline">
                    View Pricing
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Main Process Steps */}
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-3 lg:gap-12">
              <div className="flex flex-col items-center space-y-4 text-center">
                <div className="flex h-20 w-20 items-center justify-center rounded-full bg-rose-100">
                  <span className="text-3xl font-bold text-rose-700">1</span>
                </div>
                <h3 className="text-2xl font-bold">Book & Register</h3>
                <p className="text-muted-foreground text-lg">
                  Choose your package, select a date and time, and complete your registration with valid identification.
                  We'll verify your eligibility and prepare all necessary documents.
                </p>
                <div className="flex items-center gap-2 text-sm text-green-600">
                  <Check className="h-4 w-4" />
                  <span>ID verification included</span>
                </div>
              </div>
              <div className="flex flex-col items-center space-y-4 text-center">
                <div className="flex h-20 w-20 items-center justify-center rounded-full bg-rose-100">
                  <span className="text-3xl font-bold text-rose-700">2</span>
                </div>
                <h3 className="text-2xl font-bold">Virtual Ceremony</h3>
                <p className="text-muted-foreground text-lg">
                  Connect via our secure video platform with your licensed officiant and witnesses. Exchange vows in a
                  meaningful ceremony that's legally binding.
                </p>
                <div className="flex items-center gap-2 text-sm text-green-600">
                  <Check className="h-4 w-4" />
                  <span>Licensed officiant provided</span>
                </div>
              </div>
              <div className="flex flex-col items-center space-y-4 text-center">
                <div className="flex h-20 w-20 items-center justify-center rounded-full bg-rose-100">
                  <span className="text-3xl font-bold text-rose-700">3</span>
                </div>
                <h3 className="text-2xl font-bold">Official Documentation</h3>
                <p className="text-muted-foreground text-lg">
                  We handle all the paperwork and legal filing. Your official marriage certificate will be processed and
                  mailed to you within 5-7 business days.
                </p>
                <div className="flex items-center gap-2 text-sm text-green-600">
                  <Check className="h-4 w-4" />
                  <span>Certified marriage certificate</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Detailed Process */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-slate-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Detailed Process</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl">
                Here's exactly what happens from booking to receiving your marriage certificate.
              </p>
            </div>

            <div className="mx-auto max-w-4xl space-y-8">
              {processSteps.map((step, index) => (
                <Card key={index} className="p-6">
                  <CardContent className="flex items-start gap-6 p-0">
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-rose-100 flex-shrink-0">
                      <step.icon className="h-6 w-6 text-rose-700" />
                    </div>
                    <div className="space-y-2">
                      <h3 className="text-xl font-semibold">{step.title}</h3>
                      <p className="text-muted-foreground">{step.description}</p>
                      <div className="flex items-center gap-2 text-sm text-slate-600">
                        <Clock className="h-4 w-4" />
                        <span>{step.duration}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Legal Requirements */}
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Legal Requirements</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl">
                Our online marriages are legally recognized and comply with all state requirements.
              </p>
            </div>

            <div className="mx-auto grid max-w-5xl gap-6 lg:grid-cols-2 lg:gap-12">
              <div className="space-y-6">
                <h3 className="text-2xl font-semibold">What You Need</h3>
                <div className="space-y-4">
                  {requirements.map((req, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium">{req.title}</p>
                        <p className="text-sm text-muted-foreground">{req.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-6">
                <h3 className="text-2xl font-semibold">Legal Compliance</h3>
                <div className="space-y-4">
                  {compliance.map((item, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <Shield className="h-5 w-5 text-blue-500 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium">{item.title}</p>
                        <p className="text-sm text-muted-foreground">{item.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ Preview */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-slate-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Common Questions</h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl">
                Quick answers to the most frequently asked questions about online marriage.
              </p>
            </div>

            <div className="mx-auto max-w-4xl space-y-6">
              {quickFAQ.map((faq, index) => (
                <Card key={index} className="p-6">
                  <CardContent className="p-0">
                    <h3 className="text-lg font-semibold mb-2">{faq.question}</h3>
                    <p className="text-muted-foreground">{faq.answer}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="flex justify-center mt-8">
              <Link href="/faq">
                <Button variant="outline" size="lg">
                  View All FAQs
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter md:text-4xl/tight">Ready to Get Started?</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Join thousands of couples who have chosen OnlineMarriagesNow for their special day.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Link href="/booking">
                  <Button size="lg" className="bg-rose-600 hover:bg-rose-700">
                    Book Your Ceremony
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
                <Link href="/pricing">
                  <Button size="lg" variant="outline">
                    View Pricing Options
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="w-full border-t bg-slate-50 py-6 md:py-12">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <div className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </div>
          <p className="text-center text-sm text-muted-foreground md:text-left">
            © {new Date().getFullYear()} OnlineMarriagesNow. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Link href="/terms" className="text-sm text-muted-foreground hover:underline">
              Terms
            </Link>
            <Link href="/privacy" className="text-sm text-muted-foreground hover:underline">
              Privacy
            </Link>
            <Link href="/contact" className="text-sm text-muted-foreground hover:underline">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

const processSteps = [
  {
    icon: FileText,
    title: "Initial Registration & Payment",
    description:
      "Complete your booking form with personal details, upload required identification documents, and make your payment. We'll review your information within 2 hours.",
    duration: "15 minutes",
  },
  {
    icon: Shield,
    title: "Document Verification",
    description:
      "Our team verifies your identity and eligibility for marriage. We check state requirements and ensure all documentation is complete and valid.",
    duration: "2-4 hours",
  },
  {
    icon: Users,
    title: "Ceremony Scheduling",
    description:
      "Choose your preferred date and time from available slots. We'll send calendar invites and ceremony details to all participants including witnesses if required.",
    duration: "5 minutes",
  },
  {
    icon: Video,
    title: "Virtual Ceremony",
    description:
      "Join your secure video ceremony with our licensed officiant. Exchange vows, complete the legal requirements, and celebrate your marriage with family and friends.",
    duration: "15-30 minutes",
  },
  {
    icon: Award,
    title: "Certificate Processing",
    description:
      "We file all necessary paperwork with the appropriate state authorities and process your official marriage certificate. You'll receive tracking information once shipped.",
    duration: "5-7 business days",
  },
]

const requirements = [
  {
    title: "Valid Government ID",
    description: "Driver's license, passport, or state-issued ID for both parties",
  },
  {
    title: "Age Verification",
    description: "Both parties must be 18+ (or meet state-specific requirements with parental consent)",
  },
  {
    title: "Single Status",
    description: "Neither party can be currently married to someone else",
  },
  {
    title: "Stable Internet Connection",
    description: "Reliable internet and device with camera/microphone for the ceremony",
  },
  {
    title: "Witnesses (if required)",
    description: "Some states require 1-2 witnesses who can join virtually",
  },
]

const compliance = [
  {
    title: "State-Licensed Officiants",
    description: "All ceremonies performed by ordained ministers licensed in your state",
  },
  {
    title: "Legal Documentation",
    description: "Proper marriage license application and filing with state authorities",
  },
  {
    title: "Secure Platform",
    description: "HIPAA-compliant video platform with end-to-end encryption",
  },
  {
    title: "Record Keeping",
    description: "Secure storage of all marriage records and documentation",
  },
  {
    title: "State Recognition",
    description: "Marriages recognized in all 50 states and internationally",
  },
]

const quickFAQ = [
  {
    question: "Is an online marriage legally binding?",
    answer:
      "Yes! Our online marriages are 100% legal and recognized in all 50 states. We follow all state requirements and use licensed officiants.",
  },
  {
    question: "How long does the whole process take?",
    answer:
      "From booking to receiving your certificate: 7-10 days total. The ceremony itself takes 15-30 minutes, and certificates are mailed within 5-7 business days.",
  },
  {
    question: "Do we need witnesses?",
    answer:
      "It depends on your state. Some states require 1-2 witnesses who can join your ceremony virtually. We'll let you know the requirements for your state during booking.",
  },
  {
    question: "What if we're in different locations?",
    answer:
      "No problem! Both parties can join from different locations. This is perfect for military couples, long-distance relationships, or when travel isn't possible.",
  },
]
