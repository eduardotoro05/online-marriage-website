"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { Heart, ArrowLeft } from "lucide-react"

import { Button } from "@/components/ui/button"
import { CalendlyEmbed } from "@/components/calendly-embed"

export default function CalendlyBookingPage() {
  const searchParams = useSearchParams()
  const plan = searchParams.get("plan") || "premium"
  const [calendlyUrl, setCalendlyUrl] = useState("")
  const [userDetails, setUserDetails] = useState({
    name: "",
    email: "",
  })

  // In a real app, you would get these from your database or environment variables
  const planUrls = {
    essential: "https://calendly.com/onlinemarriagesnow/essential-ceremony",
    premium: "https://calendly.com/onlinemarriagesnow/premium-ceremony",
    luxury: "https://calendly.com/onlinemarriagesnow/luxury-ceremony",
  }

  useEffect(() => {
    // Set the correct Calendly URL based on the selected plan
    setCalendlyUrl(planUrls[plan as keyof typeof planUrls] || planUrls.premium)

    // In a real app, you might get user details from your auth system
    // For now, we'll use mock data
    setUserDetails({
      name: "John Smith",
      email: "john@example.com",
    })
  }, [plan])

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="/how-it-works" className="text-sm font-medium">
              How It Works
            </Link>
            <Link href="/faq" className="text-sm font-medium">
              FAQ
            </Link>
            <Link href="/pricing" className="text-sm font-medium">
              Pricing
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex-1 py-12">
        <div className="container px-4 md:px-6">
          <div className="mx-auto max-w-4xl">
            <div className="mb-8 flex items-center">
              <Button variant="outline" size="sm" asChild>
                <Link href="/booking">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Back to Booking
                </Link>
              </Button>
              <h1 className="ml-4 text-2xl font-bold">Schedule Your Ceremony</h1>
            </div>

            {calendlyUrl ? (
              <CalendlyEmbed
                url={calendlyUrl}
                prefill={{
                  name: userDetails.name,
                  email: userDetails.email,
                }}
                className="min-h-[700px] w-full border rounded-md"
              />
            ) : (
              <div className="flex h-[600px] items-center justify-center border rounded-md">
                <p>Loading scheduling calendar...</p>
              </div>
            )}
          </div>
        </div>
      </main>
      <footer className="w-full border-t bg-slate-50 py-6 md:py-12">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <div className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </div>
          <p className="text-center text-sm text-muted-foreground md:text-left">
            © {new Date().getFullYear()} OnlineMarriagesNow. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Link href="/terms" className="text-sm text-muted-foreground hover:underline">
              Terms
            </Link>
            <Link href="/privacy" className="text-sm text-muted-foreground hover:underline">
              Privacy
            </Link>
            <Link href="/contact" className="text-sm text-muted-foreground hover:underline">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
