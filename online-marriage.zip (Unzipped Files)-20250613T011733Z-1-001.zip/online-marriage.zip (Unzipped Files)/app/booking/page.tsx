"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { ArrowLeft, ArrowRight, Heart, Check, Tag, Plus, Minus, Calendar, AlertCircle, Clock } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Checkbox } from "@/components/ui/checkbox"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { CalendlyEmbed } from "@/components/calendly-embed"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function BookingPage() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [promoCode, setPromoCode] = useState("")
  const [promoDiscount, setPromoDiscount] = useState<{
    amount: number
    type: "percentage" | "fixed"
    code: string
  } | null>(null)
  const [promoLoading, setPromoLoading] = useState(false)
  const [promoError, setPromoError] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [scheduledEvent, setScheduledEvent] = useState<any>(null)
  const [paymentDeadline, setPaymentDeadline] = useState<Date | null>(null)
  const [timeRemaining, setTimeRemaining] = useState<string>("")

  // Add-ons state
  const [sameDayService, setSameDayService] = useState(false)
  const [witnessesNeeded, setWitnessesNeeded] = useState(0)
  const [apostilleStamp, setApostilleStamp] = useState(false)
  const [vowChoice, setVowChoice] = useState<"standard" | "custom">("standard")

  // Form data state
  const [formData, setFormData] = useState({
    firstName1: "",
    lastName1: "",
    email1: "",
    phone1: "",
    firstName2: "",
    lastName2: "",
    email2: "",
    phone2: "",
    address: "",
    city: "",
    state: "",
    zip: "",
  })

  // Check for scheduled event on component mount
  useEffect(() => {
    const storedEvent = localStorage.getItem("calendly_event")
    if (storedEvent) {
      setScheduledEvent(JSON.parse(storedEvent))
    }

    const storedDeadline = localStorage.getItem("payment_deadline")
    if (storedDeadline) {
      setPaymentDeadline(new Date(storedDeadline))
    }
  }, [])

  // Countdown timer effect
  useEffect(() => {
    if (!paymentDeadline) return

    const timer = setInterval(() => {
      const now = new Date()
      const timeLeft = paymentDeadline.getTime() - now.getTime()

      if (timeLeft <= 0) {
        setTimeRemaining("Expired")
        clearInterval(timer)
        // Handle expiration
        handleBookingExpiration()
      } else {
        const minutes = Math.floor(timeLeft / (1000 * 60))
        const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000)
        setTimeRemaining(`${minutes}:${seconds.toString().padStart(2, "0")}`)
      }
    }, 1000)

    return () => clearInterval(timer)
  }, [paymentDeadline])

  const handleBookingExpiration = () => {
    // Clear stored data
    localStorage.removeItem("calendly_event")
    localStorage.removeItem("payment_deadline")
    setScheduledEvent(null)
    setPaymentDeadline(null)

    // Show expiration message and redirect to scheduling
    alert("Your booking has expired. Please schedule a new ceremony time.")
    setStep(3) // Go back to scheduling step
  }

  const handleNextStep = () => {
    setStep(step + 1)
    window.scrollTo(0, 0)
  }

  const handlePrevStep = () => {
    setStep(step - 1)
    window.scrollTo(0, 0)
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  // Pricing calculations
  const basePrice = 299
  const sameDayPrice = sameDayService ? 200 : 0
  const witnessPrice = witnessesNeeded * 25
  const apostillePrice = apostilleStamp ? 150 : 0
  const subtotal = basePrice + sameDayPrice + witnessPrice + apostillePrice

  const calculateDiscountedPrice = () => {
    if (!promoDiscount) return subtotal

    if (promoDiscount.type === "percentage") {
      return Math.max(0, subtotal - (subtotal * promoDiscount.amount) / 100)
    } else {
      return Math.max(0, subtotal - promoDiscount.amount)
    }
  }

  const finalPrice = calculateDiscountedPrice()
  const discountAmount = subtotal - finalPrice

  const applyPromoCode = async () => {
    if (!promoCode.trim()) return

    setPromoLoading(true)
    setPromoError("")

    try {
      const response = await fetch("/api/validate-promo", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          promoCode: promoCode.trim(),
          amount: subtotal,
        }),
      })

      const data = await response.json()

      if (data.valid) {
        setPromoDiscount({
          amount: data.discount.amount,
          type: data.discount.type,
          code: promoCode.trim(),
        })
        setPromoError("")
      } else {
        setPromoError(data.error || "Invalid promo code")
        setPromoDiscount(null)
      }
    } catch (error) {
      setPromoError("Error validating promo code")
      setPromoDiscount(null)
    }

    setPromoLoading(false)
  }

  const removePromoCode = () => {
    setPromoCode("")
    setPromoDiscount(null)
    setPromoError("")
  }

  const handleCompleteBooking = async () => {
    setIsProcessing(true)

    try {
      const bookingData = {
        package: "standard",
        packageName: "Online Marriage Ceremony",
        originalPrice: basePrice,
        finalPrice: finalPrice,
        discount: promoDiscount,
        scheduledEvent: scheduledEvent,
        addOns: {
          sameDayService,
          witnessesNeeded,
          apostilleStamp,
          vowChoice,
        },
        pricing: {
          basePrice,
          sameDayPrice,
          witnessPrice,
          apostillePrice,
          subtotal,
          finalPrice,
        },
        participants: [
          {
            firstName: formData.firstName1,
            lastName: formData.lastName1,
            email: formData.email1,
            phone: formData.phone1,
            role: "partner1",
          },
          {
            firstName: formData.firstName2,
            lastName: formData.lastName2,
            email: formData.email2,
            phone: formData.phone2,
            role: "partner2",
          },
        ],
        address: {
          street: formData.address,
          city: formData.city,
          state: formData.state,
          zip: formData.zip,
        },
      }

      const response = await fetch("/api/book-ceremony", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(bookingData),
      })

      const result = await response.json()

      if (result.success) {
        // Clear stored data on successful payment
        localStorage.removeItem("calendly_event")
        localStorage.removeItem("payment_deadline")
        router.push(`/booking/confirmation?bookingId=${result.bookingId}`)
      } else {
        throw new Error(result.error || "Booking failed")
      }
    } catch (error) {
      console.error("Booking error:", error)
      alert("There was an error processing your booking. Please try again.")
    }

    setIsProcessing(false)
  }

  // Generate Calendly URL with add-ons info
  const getCalendlyUrl = () => {
    const baseUrl = "https://calendly.com/contact-onlinemarriagesnow/online-marriage-ceremony"
    const params = new URLSearchParams()

    // Add add-ons as custom answers
    const addOns = []
    if (sameDayService) addOns.push("Same-day service (+$200)")
    if (witnessesNeeded > 0) addOns.push(`${witnessesNeeded} witnesses (+$${witnessPrice})`)
    if (apostilleStamp) addOns.push("Apostille stamp (+$150)")

    if (addOns.length > 0) {
      params.append("a1", addOns.join(", "))
    }

    params.append("a2", `$${finalPrice}`)
    params.append("a3", vowChoice === "standard" ? "Standard" : "Custom")

    return `${baseUrl}?${params.toString()}`
  }

  // Format the scheduled event time for display
  const formatScheduledTime = (event: any) => {
    if (!event) return ""

    const startTime = new Date(event.start_time || event.scheduled_event?.start_time)
    return startTime.toLocaleString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "numeric",
      minute: "2-digit",
      timeZoneName: "short",
    })
  }

  // Check if form is filled out enough to proceed to scheduling
  const isFormFilledForScheduling = () => {
    return formData.firstName1.trim() !== "" && formData.lastName1.trim() !== "" && formData.email1.trim() !== ""
  }

  // Get the name to use for Calendly prefill
  const getCalendlyPrefillName = () => {
    if (formData.firstName1 && formData.lastName1) {
      return `${formData.firstName1} ${formData.lastName1} & ${formData.firstName2 || "Partner"}`
    }
    return ""
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="/how-it-works" className="text-sm font-medium">
              How It Works
            </Link>
            <Link href="/faq" className="text-sm font-medium">
              FAQ
            </Link>
            <Link href="/pricing" className="text-sm font-medium">
              Pricing
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex-1 py-12">
        <div className="container px-4 md:px-6">
          <div className="mx-auto max-w-4xl">
            <div className="mb-8">
              <h1 className="text-3xl font-bold tracking-tighter">Book Your Online Marriage Ceremony</h1>
              <p className="text-muted-foreground">Complete the steps below to schedule your ceremony</p>
            </div>

            <div className="mb-8">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div
                    className={`flex h-8 w-8 items-center justify-center rounded-full ${step >= 1 ? "bg-rose-600 text-white" : "bg-muted text-muted-foreground"}`}
                  >
                    1
                  </div>
                  <div className={`mx-2 h-1 w-12 ${step >= 2 ? "bg-rose-600" : "bg-muted"}`}></div>
                  <div
                    className={`flex h-8 w-8 items-center justify-center rounded-full ${step >= 2 ? "bg-rose-600 text-white" : "bg-muted text-muted-foreground"}`}
                  >
                    2
                  </div>
                  <div className={`mx-2 h-1 w-12 ${step >= 3 ? "bg-rose-600" : "bg-muted"}`}></div>
                  <div
                    className={`flex h-8 w-8 items-center justify-center rounded-full ${step >= 3 ? "bg-rose-600 text-white" : "bg-muted text-muted-foreground"}`}
                  >
                    3
                  </div>
                  <div className={`mx-2 h-1 w-12 ${step >= 4 ? "bg-rose-600" : "bg-muted"}`}></div>
                  <div
                    className={`flex h-8 w-8 items-center justify-center rounded-full ${step >= 4 ? "bg-rose-600 text-white" : "bg-muted text-muted-foreground"}`}
                  >
                    4
                  </div>
                </div>
              </div>
              <div className="mt-2 flex justify-between text-sm">
                <span className={step >= 1 ? "text-foreground" : "text-muted-foreground"}>Customize</span>
                <span className={step >= 2 ? "text-foreground" : "text-muted-foreground"}>Your Details</span>
                <span className={step >= 3 ? "text-foreground" : "text-muted-foreground"}>Schedule</span>
                <span className={step >= 4 ? "text-foreground" : "text-muted-foreground"}>Payment</span>
              </div>
            </div>

            {step === 1 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold">Customize Your Ceremony</h2>

                {/* Base Package */}
                <Card className="border-rose-200 bg-rose-50">
                  <CardHeader>
                    <CardTitle>Online Marriage Ceremony - $299</CardTitle>
                    <CardDescription>Everything you need for a legal marriage ceremony</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-2 text-sm">
                      <div className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-500" />
                        <span>Licensed officiant</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-500" />
                        <span>Legal marriage certificate</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-500" />
                        <span>30-minute ceremony</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-500" />
                        <span>Unlimited guests</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-500" />
                        <span>Ceremony recording</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Vow Choice */}
                <Card>
                  <CardHeader>
                    <CardTitle>Choose Your Vows</CardTitle>
                    <CardDescription>Select how you'd like to handle your wedding vows</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <RadioGroup value={vowChoice} onValueChange={(value: "standard" | "custom") => setVowChoice(value)}>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="standard" id="standard" />
                        <Label htmlFor="standard">Use our standard vows (recommended)</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="custom" id="custom" />
                        <Label htmlFor="custom">I'll write my own vows</Label>
                      </div>
                    </RadioGroup>
                  </CardContent>
                </Card>

                {/* Add-ons */}
                <Card>
                  <CardHeader>
                    <CardTitle>Optional Add-ons</CardTitle>
                    <CardDescription>Customize your ceremony with these optional extras</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Same Day Service */}
                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Checkbox
                          id="same-day"
                          checked={sameDayService}
                          onCheckedChange={(checked) => setSameDayService(checked as boolean)}
                        />
                        <div>
                          <Label htmlFor="same-day" className="font-medium">
                            Same-Day Ceremony
                          </Label>
                          <p className="text-sm text-muted-foreground">Get married today! Subject to availability.</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold">+$200</div>
                      </div>
                    </div>

                    {/* Witnesses */}
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <Label className="font-medium">Professional Witnesses</Label>
                          <p className="text-sm text-muted-foreground">
                            We'll provide witnesses if needed by your state
                          </p>
                        </div>
                        <div className="text-right">
                          <div className="font-bold">$25 each</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setWitnessesNeeded(Math.max(0, witnessesNeeded - 1))}
                          disabled={witnessesNeeded === 0}
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                        <span className="w-8 text-center">{witnessesNeeded}</span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setWitnessesNeeded(Math.min(4, witnessesNeeded + 1))}
                          disabled={witnessesNeeded === 4}
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                        <span className="text-sm text-muted-foreground ml-2">witnesses needed</span>
                      </div>
                    </div>

                    {/* Apostille */}
                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Checkbox
                          id="apostille"
                          checked={apostilleStamp}
                          onCheckedChange={(checked) => setApostilleStamp(checked as boolean)}
                        />
                        <div>
                          <Label htmlFor="apostille" className="font-medium">
                            Apostille Stamp
                          </Label>
                          <p className="text-sm text-muted-foreground">International authentication for use abroad</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-bold">+$150</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Pricing Summary */}
                <Card>
                  <CardHeader>
                    <CardTitle>Pricing Summary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Base ceremony</span>
                        <span>${basePrice}</span>
                      </div>
                      {sameDayService && (
                        <div className="flex justify-between">
                          <span>Same-day service</span>
                          <span>+${sameDayPrice}</span>
                        </div>
                      )}
                      {witnessesNeeded > 0 && (
                        <div className="flex justify-between">
                          <span>Witnesses ({witnessesNeeded})</span>
                          <span>+${witnessPrice}</span>
                        </div>
                      )}
                      {apostilleStamp && (
                        <div className="flex justify-between">
                          <span>Apostille stamp</span>
                          <span>+${apostillePrice}</span>
                        </div>
                      )}
                      <Separator />
                      <div className="flex justify-between font-bold text-lg">
                        <span>Total</span>
                        <span>${subtotal}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="flex justify-end">
                  <Button onClick={handleNextStep} className="bg-rose-600 hover:bg-rose-700">
                    Continue to Your Details
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold">Enter Your Details</h2>
                <p className="text-muted-foreground">
                  Please provide your information below. This will help us personalize your ceremony and send you
                  important updates.
                </p>

                <div className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <label htmlFor="first-name-1" className="text-sm font-medium">
                        First Person - First Name*
                      </label>
                      <Input
                        id="first-name-1"
                        placeholder="Enter first name"
                        value={formData.firstName1}
                        onChange={(e) => handleInputChange("firstName1", e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="last-name-1" className="text-sm font-medium">
                        First Person - Last Name*
                      </label>
                      <Input
                        id="last-name-1"
                        placeholder="Enter last name"
                        value={formData.lastName1}
                        onChange={(e) => handleInputChange("lastName1", e.target.value)}
                        required
                      />
                    </div>
                  </div>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <label htmlFor="email-1" className="text-sm font-medium">
                        First Person - Email*
                      </label>
                      <Input
                        id="email-1"
                        type="email"
                        placeholder="Enter email"
                        value={formData.email1}
                        onChange={(e) => handleInputChange("email1", e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="phone-1" className="text-sm font-medium">
                        First Person - Phone
                      </label>
                      <Input
                        id="phone-1"
                        placeholder="Enter phone number"
                        value={formData.phone1}
                        onChange={(e) => handleInputChange("phone1", e.target.value)}
                      />
                    </div>
                  </div>

                  <Separator className="my-4" />

                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <label htmlFor="first-name-2" className="text-sm font-medium">
                        Second Person - First Name
                      </label>
                      <Input
                        id="first-name-2"
                        placeholder="Enter first name"
                        value={formData.firstName2}
                        onChange={(e) => handleInputChange("firstName2", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="last-name-2" className="text-sm font-medium">
                        Second Person - Last Name
                      </label>
                      <Input
                        id="last-name-2"
                        placeholder="Enter last name"
                        value={formData.lastName2}
                        onChange={(e) => handleInputChange("lastName2", e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="grid gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <label htmlFor="email-2" className="text-sm font-medium">
                        Second Person - Email
                      </label>
                      <Input
                        id="email-2"
                        type="email"
                        placeholder="Enter email"
                        value={formData.email2}
                        onChange={(e) => handleInputChange("email2", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="phone-2" className="text-sm font-medium">
                        Second Person - Phone
                      </label>
                      <Input
                        id="phone-2"
                        placeholder="Enter phone number"
                        value={formData.phone2}
                        onChange={(e) => handleInputChange("phone2", e.target.value)}
                      />
                    </div>
                  </div>

                  <Separator className="my-4" />

                  <div className="space-y-2">
                    <label htmlFor="address" className="text-sm font-medium">
                      Mailing Address (for certificate)
                    </label>
                    <Input
                      id="address"
                      placeholder="Enter street address"
                      value={formData.address}
                      onChange={(e) => handleInputChange("address", e.target.value)}
                    />
                  </div>
                  <div className="grid gap-4 md:grid-cols-3">
                    <div className="space-y-2">
                      <label htmlFor="city" className="text-sm font-medium">
                        City
                      </label>
                      <Input
                        id="city"
                        placeholder="Enter city"
                        value={formData.city}
                        onChange={(e) => handleInputChange("city", e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="state" className="text-sm font-medium">
                        State
                      </label>
                      <Select value={formData.state} onValueChange={(value) => handleInputChange("state", value)}>
                        <SelectTrigger id="state">
                          <SelectValue placeholder="Select state" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="AL">Alabama</SelectItem>
                          <SelectItem value="AK">Alaska</SelectItem>
                          <SelectItem value="AZ">Arizona</SelectItem>
                          <SelectItem value="CA">California</SelectItem>
                          <SelectItem value="FL">Florida</SelectItem>
                          <SelectItem value="NY">New York</SelectItem>
                          <SelectItem value="TX">Texas</SelectItem>
                          <SelectItem value="WY">Wyoming</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="zip" className="text-sm font-medium">
                        ZIP Code
                      </label>
                      <Input
                        id="zip"
                        placeholder="Enter ZIP code"
                        value={formData.zip}
                        onChange={(e) => handleInputChange("zip", e.target.value)}
                      />
                    </div>
                  </div>
                </div>

                <Alert variant="default" className="bg-blue-50 border-blue-200 text-blue-800">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Next: Choose Your Ceremony Date</AlertTitle>
                  <AlertDescription>
                    After entering your details, you'll select your preferred ceremony date and time. We'll use the
                    information you provided to schedule your ceremony.
                  </AlertDescription>
                </Alert>

                <div className="flex justify-between">
                  <Button variant="outline" onClick={handlePrevStep}>
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Back
                  </Button>
                  <Button
                    onClick={handleNextStep}
                    className="bg-rose-600 hover:bg-rose-700"
                    disabled={!isFormFilledForScheduling()}
                  >
                    Continue to Schedule
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>

                {!isFormFilledForScheduling() && (
                  <p className="text-sm text-rose-600 text-center">
                    Please fill out at least the first person's name and email to continue.
                  </p>
                )}
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold">Schedule Your Ceremony</h2>
                <p className="text-muted-foreground">Select your preferred date and time from the calendar below.</p>

                {sameDayService && (
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="text-blue-800 font-medium">Same-day service selected!</p>
                    <p className="text-blue-700 text-sm">
                      You can select today's date. We'll confirm availability within 2 hours.
                    </p>
                  </div>
                )}

                {/* Payment deadline warning */}
                <Alert className="bg-amber-50 border-amber-200 text-amber-800">
                  <Clock className="h-4 w-4" />
                  <AlertTitle>Important: Payment Required</AlertTitle>
                  <AlertDescription>
                    Your ceremony slot will be temporarily reserved for 30 minutes after scheduling. You must complete
                    payment within this time to confirm your booking, or the slot will be automatically released.
                  </AlertDescription>
                </Alert>

                {/* Show scheduled event if one exists */}
                {scheduledEvent && (
                  <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Calendar className="h-5 w-5 text-green-600" />
                      <p className="text-green-800 font-medium">Ceremony Scheduled!</p>
                    </div>
                    <p className="text-green-700 text-sm">{formatScheduledTime(scheduledEvent)}</p>
                    {paymentDeadline && timeRemaining && timeRemaining !== "Expired" && (
                      <div className="mt-2 flex items-center gap-2">
                        <Clock className="h-4 w-4 text-amber-600" />
                        <span className="text-amber-800 font-medium">Complete payment within: {timeRemaining}</span>
                      </div>
                    )}
                  </div>
                )}

                {/* Calendly Embed - With prefilled data */}
                <div className="w-full">
                  <CalendlyEmbed
                    url={getCalendlyUrl()}
                    prefill={{
                      name: getCalendlyPrefillName(),
                      email: formData.email1,
                    }}
                    onEventScheduled={(eventData) => {
                      setScheduledEvent(eventData)
                      localStorage.setItem("calendly_event", JSON.stringify(eventData))

                      // Set payment deadline (30 minutes from now)
                      const deadline = new Date(Date.now() + 30 * 60 * 1000)
                      setPaymentDeadline(deadline)
                      localStorage.setItem("payment_deadline", deadline.toISOString())
                    }}
                    className="w-full"
                  />
                </div>

                <div className="flex justify-between">
                  <Button variant="outline" onClick={handlePrevStep}>
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Back to Your Details
                  </Button>
                  <Button onClick={handleNextStep} className="bg-rose-600 hover:bg-rose-700" disabled={!scheduledEvent}>
                    Continue to Payment
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}

            {step === 4 && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold">Payment & Confirmation</h2>

                {/* Payment countdown */}
                {paymentDeadline && timeRemaining && timeRemaining !== "Expired" && (
                  <Alert className="bg-red-50 border-red-200 text-red-800">
                    <Clock className="h-4 w-4" />
                    <AlertTitle>Complete Payment Now</AlertTitle>
                    <AlertDescription>
                      <div className="flex items-center gap-2">
                        <span>Time remaining to complete payment:</span>
                        <span className="font-bold text-lg">{timeRemaining}</span>
                      </div>
                      <p className="mt-1 text-sm">
                        Your booking will be automatically cancelled if payment is not completed in time.
                      </p>
                    </AlertDescription>
                  </Alert>
                )}

                {/* Show scheduled time */}
                {scheduledEvent && (
                  <Card className="border-green-200 bg-green-50">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Calendar className="h-5 w-5 text-green-600" />
                        Scheduled Ceremony
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-green-800 font-medium">{formatScheduledTime(scheduledEvent)}</p>
                    </CardContent>
                  </Card>
                )}

                {/* Promo Code Section */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Tag className="h-5 w-5" />
                      Promo Code
                    </CardTitle>
                    <CardDescription>Have a promo code? Enter it below to apply your discount.</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {!promoDiscount ? (
                      <div className="flex gap-2">
                        <Input
                          placeholder="Enter promo code"
                          value={promoCode}
                          onChange={(e) => setPromoCode(e.target.value)}
                          onKeyPress={(e) => e.key === "Enter" && applyPromoCode()}
                        />
                        <Button onClick={applyPromoCode} disabled={!promoCode.trim() || promoLoading} variant="outline">
                          {promoLoading ? "Checking..." : "Apply"}
                        </Button>
                      </div>
                    ) : (
                      <div className="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-lg">
                        <div className="flex items-center gap-2">
                          <Check className="h-4 w-4 text-green-600" />
                          <span className="text-green-800 font-medium">Code "{promoDiscount.code}" applied!</span>
                        </div>
                        <Button onClick={removePromoCode} variant="ghost" size="sm">
                          Remove
                        </Button>
                      </div>
                    )}
                    {promoError && <p className="text-sm text-red-600 mt-2">{promoError}</p>}
                  </CardContent>
                </Card>

                {/* Order Summary */}
                <div className="rounded-lg border p-6">
                  <h3 className="mb-4 text-xl font-bold">Order Summary</h3>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span>Online Marriage Ceremony</span>
                      <span>${basePrice}</span>
                    </div>
                    {sameDayService && (
                      <div className="flex justify-between">
                        <span>Same-day service</span>
                        <span>+${sameDayPrice}</span>
                      </div>
                    )}
                    {witnessesNeeded > 0 && (
                      <div className="flex justify-between">
                        <span>Professional witnesses ({witnessesNeeded})</span>
                        <span>+${witnessPrice}</span>
                      </div>
                    )}
                    {apostilleStamp && (
                      <div className="flex justify-between">
                        <span>Apostille stamp</span>
                        <span>+${apostillePrice}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span>Vow preference</span>
                      <span>{vowChoice === "standard" ? "Standard vows" : "Custom vows"}</span>
                    </div>
                    {promoDiscount && (
                      <div className="flex justify-between text-green-600">
                        <span>Discount ({promoDiscount.code})</span>
                        <span>-${discountAmount.toFixed(2)}</span>
                      </div>
                    )}
                    <Separator />
                    <div className="flex justify-between font-bold">
                      <span>Total</span>
                      <span>
                        {promoDiscount && subtotal !== finalPrice && (
                          <span className="text-muted-foreground line-through mr-2">${subtotal}</span>
                        )}
                        ${finalPrice.toFixed(2)}
                      </span>
                    </div>
                    {finalPrice === 0 && (
                      <div className="text-center p-3 bg-green-50 border border-green-200 rounded-lg">
                        <p className="text-green-800 font-medium">🎉 Your ceremony is completely free!</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Payment Information - Only show if not free */}
                {finalPrice > 0 && (
                  <div className="space-y-4">
                    <h3 className="text-xl font-bold">Payment Information</h3>
                    <div className="space-y-2">
                      <label htmlFor="card-name" className="text-sm font-medium">
                        Name on Card
                      </label>
                      <Input id="card-name" placeholder="Enter name as it appears on card" />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="card-number" className="text-sm font-medium">
                        Card Number
                      </label>
                      <Input id="card-number" placeholder="1234 5678 9012 3456" />
                    </div>
                    <div className="grid gap-4 md:grid-cols-3">
                      <div className="space-y-2">
                        <label htmlFor="expiry-month" className="text-sm font-medium">
                          Expiry Month
                        </label>
                        <Select>
                          <SelectTrigger id="expiry-month">
                            <SelectValue placeholder="Month" />
                          </SelectTrigger>
                          <SelectContent>
                            {Array.from({ length: 12 }, (_, i) => (
                              <SelectItem key={i + 1} value={(i + 1).toString().padStart(2, "0")}>
                                {(i + 1).toString().padStart(2, "0")}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="expiry-year" className="text-sm font-medium">
                          Expiry Year
                        </label>
                        <Select>
                          <SelectTrigger id="expiry-year">
                            <SelectValue placeholder="Year" />
                          </SelectTrigger>
                          <SelectContent>
                            {Array.from({ length: 10 }, (_, i) => (
                              <SelectItem key={i} value={(new Date().getFullYear() + i).toString()}>
                                {new Date().getFullYear() + i}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="cvv" className="text-sm font-medium">
                          CVV
                        </label>
                        <Input id="cvv" placeholder="123" />
                      </div>
                    </div>
                  </div>
                )}

                <div className="rounded-lg border bg-slate-50 p-4">
                  <p className="text-sm text-muted-foreground">
                    By clicking "{finalPrice === 0 ? "Complete Free Booking" : "Complete Booking"}", you agree to our{" "}
                    <Link href="/terms" className="text-rose-600 hover:underline">
                      Terms of Service
                    </Link>{" "}
                    and{" "}
                    <Link href="/privacy" className="text-rose-600 hover:underline">
                      Privacy Policy
                    </Link>
                    {finalPrice > 0 && <>. Your card will be charged ${finalPrice.toFixed(2)}</>}.
                  </p>
                </div>

                <div className="flex justify-between">
                  <Button variant="outline" onClick={handlePrevStep}>
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Back
                  </Button>
                  <Button
                    onClick={handleCompleteBooking}
                    className="bg-rose-600 hover:bg-rose-700"
                    disabled={isProcessing}
                  >
                    {isProcessing ? "Processing..." : finalPrice === 0 ? "Complete Free Booking" : "Complete Booking"}
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
      <footer className="w-full border-t bg-slate-50 py-6 md:py-12">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <div className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </div>
          <p className="text-center text-sm text-muted-foreground md:text-left">
            © {new Date().getFullYear()} OnlineMarriagesNow. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Link href="/terms" className="text-sm text-muted-foreground hover:underline">
              Terms
            </Link>
            <Link href="/privacy" className="text-sm text-muted-foreground hover:underline">
              Privacy
            </Link>
            <Link href="/contact" className="text-sm text-muted-foreground hover:underline">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
