"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { useSearchParams } from "next/navigation"
import { CalendarCheck, Check, Heart, Video, Mail, Clock, Users, MapPin } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface BookingDetails {
  id: string
  status: string
  package: string
  ceremonyDate: string
  ceremonyTime: string
  partner1Name: string
  partner2Name: string
  partner1Email: string
  partner2Email: string
  totalAmount: number
  promoCode?: string
  discount?: number
  finalAmount: number
  zoomMeetingId?: string
  zoomJoinUrl?: string
  zoomPassword?: string
  createdAt: string
}

export default function ConfirmationPage() {
  const searchParams = useSearchParams()
  const bookingId = searchParams.get("bookingId")
  const [loading, setLoading] = useState(true)
  const [bookingDetails, setBookingDetails] = useState<BookingDetails | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchBookingDetails = async () => {
      if (!bookingId) {
        setError("No booking ID provided")
        setLoading(false)
        return
      }

      try {
        const response = await fetch(`/api/booking/${bookingId}`)
        if (response.ok) {
          const data = await response.json()
          setBookingDetails(data)
        } else {
          // Fallback to mock data for now since we don't have a database yet
          setBookingDetails({
            id: bookingId,
            status: "Confirmed",
            package: "Premium",
            ceremonyDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString(),
            ceremonyTime: "2:00 PM EST",
            partner1Name: "Partner 1",
            partner2Name: "Partner 2",
            partner1Email: "partner1@example.com",
            partner2Email: "partner2@example.com",
            totalAmount: 299,
            finalAmount: 0,
            promoCode: "TESTER",
            discount: 299,
            zoomMeetingId: "123-456-789",
            zoomJoinUrl: "https://zoom.us/j/123456789",
            zoomPassword: "wedding123",
            createdAt: new Date().toISOString(),
          })
        }
      } catch (err) {
        setError("Failed to load booking details")
      } finally {
        setLoading(false)
      }
    }

    fetchBookingDetails()
  }, [bookingId])

  if (loading) {
    return (
      <div className="flex min-h-screen flex-col">
        <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container flex h-16 items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Heart className="h-6 w-6 text-rose-500" />
              <span className="text-xl font-semibold">OnlineMarriagesNow</span>
            </Link>
          </div>
        </header>
        <main className="flex-1 flex items-center justify-center">
          <div className="flex flex-col items-center justify-center space-y-4">
            <div className="h-12 w-12 animate-spin rounded-full border-4 border-rose-200 border-t-rose-600"></div>
            <p className="text-lg">Loading your booking details...</p>
          </div>
        </main>
      </div>
    )
  }

  if (error || !bookingDetails) {
    return (
      <div className="flex min-h-screen flex-col">
        <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container flex h-16 items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Heart className="h-6 w-6 text-rose-500" />
              <span className="text-xl font-semibold">OnlineMarriagesNow</span>
            </Link>
          </div>
        </header>
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center space-y-4">
            <h1 className="text-2xl font-bold">Booking Not Found</h1>
            <p className="text-muted-foreground">{error || "We couldn't find your booking details."}</p>
            <Link href="/">
              <Button>Return to Home</Button>
            </Link>
          </div>
        </main>
      </div>
    )
  }

  const isFree = bookingDetails.finalAmount === 0

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="/how-it-works" className="text-sm font-medium">
              How It Works
            </Link>
            <Link href="/faq" className="text-sm font-medium">
              FAQ
            </Link>
            <Link href="/pricing" className="text-sm font-medium">
              Pricing
            </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1 py-8">
        <div className="container px-4 md:px-6">
          <div className="mx-auto max-w-4xl space-y-8">
            {/* Success Header */}
            <div className="text-center space-y-4">
              <div className="flex justify-center">
                <div className="flex h-20 w-20 items-center justify-center rounded-full bg-green-100">
                  <Check className="h-10 w-10 text-green-600" />
                </div>
              </div>
              <div>
                <h1 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">🎉 Congratulations!</h1>
                <p className="text-xl text-muted-foreground mt-2">
                  Your marriage ceremony has been successfully booked
                </p>
                <Badge variant={isFree ? "secondary" : "default"} className="mt-2">
                  {isFree ? "Free Ceremony" : "Paid Booking"}
                </Badge>
              </div>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              {/* Booking Details */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CalendarCheck className="h-5 w-5 text-rose-600" />
                    Booking Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Booking ID</p>
                      <p className="font-mono font-medium">{bookingDetails.id}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Status</p>
                      <Badge variant="default" className="bg-green-100 text-green-800">
                        {bookingDetails.status}
                      </Badge>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Package</p>
                      <p className="font-medium">{bookingDetails.package}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Booked On</p>
                      <p className="font-medium">{new Date(bookingDetails.createdAt).toLocaleDateString()}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Ceremony Details */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="h-5 w-5 text-rose-600" />
                    Ceremony Schedule
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <CalendarCheck className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="font-medium">{bookingDetails.ceremonyDate}</p>
                        <p className="text-sm text-muted-foreground">Ceremony Date</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Clock className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="font-medium">{bookingDetails.ceremonyTime}</p>
                        <p className="text-sm text-muted-foreground">Start Time</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <MapPin className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <p className="font-medium">Online via Zoom</p>
                        <p className="text-sm text-muted-foreground">Virtual Ceremony</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Couple Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-rose-600" />
                    Couple Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div>
                      <p className="font-medium">{bookingDetails.partner1Name}</p>
                      <p className="text-sm text-muted-foreground">{bookingDetails.partner1Email}</p>
                    </div>
                    <div className="border-t pt-3">
                      <p className="font-medium">{bookingDetails.partner2Name}</p>
                      <p className="text-sm text-muted-foreground">{bookingDetails.partner2Email}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Payment Summary */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Check className="h-5 w-5 text-rose-600" />
                    Payment Summary
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Package Price</span>
                      <span>${bookingDetails.totalAmount}</span>
                    </div>
                    {bookingDetails.promoCode && (
                      <div className="flex justify-between text-green-600">
                        <span>Promo Code ({bookingDetails.promoCode})</span>
                        <span>-${bookingDetails.discount}</span>
                      </div>
                    )}
                    <div className="border-t pt-2 flex justify-between font-bold text-lg">
                      <span>Total Paid</span>
                      <span className={isFree ? "text-green-600" : ""}>
                        {isFree ? "FREE" : `$${bookingDetails.finalAmount}`}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Zoom Meeting Details */}
            {bookingDetails.zoomMeetingId && (
              <Card className="border-rose-200 bg-rose-50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Video className="h-5 w-5 text-rose-600" />
                    Your Zoom Meeting Details
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <p className="text-sm text-muted-foreground">Meeting ID</p>
                      <p className="font-mono font-medium">{bookingDetails.zoomMeetingId}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Password</p>
                      <p className="font-mono font-medium">{bookingDetails.zoomPassword}</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-2">Join URL</p>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={bookingDetails.zoomJoinUrl || ""}
                        readOnly
                        className="flex-1 px-3 py-2 text-sm border rounded-md bg-white"
                      />
                      <Button size="sm" onClick={() => navigator.clipboard.writeText(bookingDetails.zoomJoinUrl || "")}>
                        Copy
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Next Steps */}
            <Card className="border-blue-200 bg-blue-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CalendarCheck className="h-5 w-5 text-blue-600" />
                  What Happens Next?
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-100 text-xs font-bold text-blue-600">
                      1
                    </div>
                    <div>
                      <p className="font-medium">Check Your Email</p>
                      <p className="text-sm text-muted-foreground">
                        We've sent confirmation emails to both partners with all ceremony details and Zoom meeting
                        information.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-100 text-xs font-bold text-blue-600">
                      2
                    </div>
                    <div>
                      <p className="font-medium">Prepare Your Documents</p>
                      <p className="text-sm text-muted-foreground">
                        Have your government-issued IDs ready for verification during the ceremony.
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="flex h-6 w-6 items-center justify-center rounded-full bg-blue-100 text-xs font-bold text-blue-600">
                      3
                    </div>
                    <div>
                      <p className="font-medium">Join Your Ceremony</p>
                      <p className="text-sm text-muted-foreground">
                        Use the Zoom link above to join your ceremony 5 minutes before the scheduled time.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-rose-600 hover:bg-rose-700">
                <Link href="/dashboard">
                  <Users className="mr-2 h-4 w-4" />
                  View Dashboard
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link href="/">
                  <Heart className="mr-2 h-4 w-4" />
                  Return Home
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link href="mailto:support@onlinemarriagesnow.com">
                  <Mail className="mr-2 h-4 w-4" />
                  Contact Support
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </main>

      <footer className="w-full border-t bg-slate-50 py-6 md:py-12">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <div className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </div>
          <p className="text-center text-sm text-muted-foreground md:text-left">
            © {new Date().getFullYear()} OnlineMarriagesNow. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Link href="/terms" className="text-sm text-muted-foreground hover:underline">
              Terms
            </Link>
            <Link href="/privacy" className="text-sm text-muted-foreground hover:underline">
              Privacy
            </Link>
            <Link href="/contact" className="text-sm text-muted-foreground hover:underline">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
