import Link from "next/link"
import { Heart } from "lucide-react"

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Button } from "@/components/ui/button"

export default function FAQPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="/how-it-works" className="text-sm font-medium">
              How It Works
            </Link>
            <Link href="/faq" className="text-sm font-medium text-rose-600">
              FAQ
            </Link>
            <Link href="/pricing" className="text-sm font-medium">
              Pricing
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/booking">
              <Button>Get Married Now</Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-3xl space-y-8">
              <div className="space-y-2 text-center">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Frequently Asked Questions
                </h1>
                <p className="text-muted-foreground md:text-xl">
                  Everything you need to know about our online marriage service
                </p>
              </div>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger>Are online marriages legally recognized?</AccordionTrigger>
                  <AccordionContent>
                    Yes, online marriages performed through our service are legally recognized in the United States. We
                    ensure compliance with state-specific requirements and provide all necessary documentation. Our
                    officiants are legally authorized to perform marriages in all 50 states.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-2">
                  <AccordionTrigger>Which states allow online marriages?</AccordionTrigger>
                  <AccordionContent>
                    Currently, most U.S. states recognize marriages performed via video conferencing, especially since
                    the COVID-19 pandemic. However, specific requirements vary by state. During the booking process,
                    we'll guide you through your state's specific requirements and ensure all legal criteria are met.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-3">
                  <AccordionTrigger>What documents do we need?</AccordionTrigger>
                  <AccordionContent>
                    Both parties will need valid government-issued photo identification (such as a driver's license or
                    passport). Depending on your state, you may also need to provide birth certificates, proof of
                    divorce (if applicable), and complete a marriage license application. Our system will guide you
                    through the specific requirements for your location.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-4">
                  <AccordionTrigger>How does the ceremony work?</AccordionTrigger>
                  <AccordionContent>
                    Our ceremonies are conducted via secure video conferencing. You'll be joined by a licensed officiant
                    and, if required by your state, witnesses. The ceremony follows a traditional format that you can
                    customize. You'll exchange vows, the officiant will pronounce you married, and all parties will sign
                    the digital marriage certificate.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-5">
                  <AccordionTrigger>Can we customize our ceremony?</AccordionTrigger>
                  <AccordionContent>
                    While we provide standard ceremony scripts, you're welcome to customize your vows and ceremony
                    structure. Our premium packages include more extensive customization options, including personalized
                    ceremony scripts and the ability to incorporate cultural or religious elements.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-6">
                  <AccordionTrigger>How long does the ceremony take?</AccordionTrigger>
                  <AccordionContent>
                    The standard ceremony lasts approximately 15-20 minutes. However, we schedule 30-minute slots to
                    allow for technical setup and any unexpected delays. Premium packages offer extended time slots for
                    more elaborate ceremonies.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-7">
                  <AccordionTrigger>Can family and friends attend?</AccordionTrigger>
                  <AccordionContent>
                    Yes! Our standard package allows up to 10 guests to join the video conference. Premium packages
                    allow for up to 100 virtual attendees. We also offer the option to livestream your ceremony to
                    YouTube or Facebook for unlimited viewing.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-8">
                  <AccordionTrigger>How quickly can we get married?</AccordionTrigger>
                  <AccordionContent>
                    Depending on your state's requirements, we can arrange ceremonies as quickly as same-day. Some
                    states have waiting periods after obtaining a marriage license, while others do not. Our expedited
                    service can help navigate the process as quickly as legally possible.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-9">
                  <AccordionTrigger>What happens if there are technical issues?</AccordionTrigger>
                  <AccordionContent>
                    Our technical support team is available during all ceremonies to address any issues. If significant
                    technical problems occur that prevent the ceremony from proceeding, we'll reschedule at no
                    additional cost. We recommend testing your equipment before the ceremony using our pre-ceremony
                    check system.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-10">
                  <AccordionTrigger>How do we receive our marriage certificate?</AccordionTrigger>
                  <AccordionContent>
                    After your ceremony, we process all necessary paperwork with the appropriate government offices.
                    You'll receive a digital copy of your marriage certificate immediately, and a physical copy will be
                    mailed to your address within 7-10 business days. Expedited shipping options are available.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
              <div className="text-center">
                <p className="mb-4 text-muted-foreground">Don't see your question answered here?</p>
                <Link href="/contact">
                  <Button variant="outline">Contact Our Support Team</Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t bg-slate-50 py-6 md:py-12">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <div className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </div>
          <p className="text-center text-sm text-muted-foreground md:text-left">
            © {new Date().getFullYear()} OnlineMarriagesNow. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Link href="/terms" className="text-sm text-muted-foreground hover:underline">
              Terms
            </Link>
            <Link href="/privacy" className="text-sm text-muted-foreground hover:underline">
              Privacy
            </Link>
            <Link href="/contact" className="text-sm text-muted-foreground hover:underline">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
