"use client"

import { useState } from "react"
import Link from "next/link"
import { Heart, FileText } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SimpleDocumentUploader } from "@/components/simple-document-uploader"
import { SimpleDocumentDownloader } from "@/components/simple-document-downloader"

export default function DocumentsPage() {
  const [activeTab, setActiveTab] = useState("download")

  // Mock user data - in a real app, this would come from your auth system
  const user = {
    name: "John & Jane Doe",
    email: "couple@example.com",
    bookingId: "BK-12345",
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="/dashboard" className="text-sm font-medium">
              Dashboard
            </Link>
            <Link href="/dashboard/documents" className="text-sm font-medium text-rose-600">
              Documents
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Button variant="outline" size="sm">
              Log Out
            </Button>
          </div>
        </div>
      </header>
      <main className="flex-1 py-12">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-4">
            <div className="lg:col-span-1">
              <div className="space-y-4">
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold tracking-tight">Documents</h2>
                  <p className="text-muted-foreground">Manage your marriage application and documents</p>
                </div>
                <nav className="flex flex-col space-y-2">
                  <Button variant="ghost" className="justify-start" asChild>
                    <Link href="/dashboard">
                      <Heart className="mr-2 h-4 w-4" />
                      Ceremony
                    </Link>
                  </Button>
                  <Button variant="ghost" className="justify-start" asChild>
                    <Link href="/dashboard/participants">
                      <FileText className="mr-2 h-4 w-4" />
                      Participants
                    </Link>
                  </Button>
                  <Button variant="secondary" className="justify-start" asChild>
                    <Link href="/dashboard/documents">
                      <FileText className="mr-2 h-4 w-4" />
                      Documents
                    </Link>
                  </Button>
                </nav>
              </div>
            </div>
            <div className="lg:col-span-3">
              <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="space-y-4">
                <TabsList>
                  <TabsTrigger value="download">Download Forms</TabsTrigger>
                  <TabsTrigger value="upload">Upload Documents</TabsTrigger>
                </TabsList>

                <TabsContent value="download" className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Download Required Forms</CardTitle>
                      <CardDescription>
                        Access and download all necessary forms for your marriage application
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <SimpleDocumentDownloader />
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="upload" className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>Upload Your Documents</CardTitle>
                      <CardDescription>Submit your identification and signed application forms</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <SimpleDocumentUploader
                        bookingId={user.bookingId}
                        customerName={user.name}
                        customerEmail={user.email}
                      />
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </main>
      <footer className="w-full border-t bg-slate-50 py-6">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <div className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </div>
          <p className="text-center text-sm text-muted-foreground md:text-left">
            © {new Date().getFullYear()} OnlineMarriagesNow. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}
