"use client"

import { useState } from "react"
import Link from "next/link"
import { Heart, Calendar, Users, FileText, Settings, Plus, Mail, Trash2, Edit } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"

export default function ParticipantsPage() {
  const [showAddParticipant, setShowAddParticipant] = useState(false)

  // Mock data - in a real app, this would come from your database
  const participants = [
    { id: 1, name: "John Smith", email: "john@example.com", role: "Partner 1", status: "Confirmed" },
    { id: 2, name: "Jane Doe", email: "jane@example.com", role: "Partner 2", status: "Confirmed" },
    { id: 3, name: "Rev. Michael Johnson", email: "rev.michael@example.com", role: "Officiant", status: "Confirmed" },
    { id: 4, name: "Sarah Williams", email: "sarah@example.com", role: "Witness", status: "Pending" },
    { id: 5, name: "Robert Brown", email: "robert@example.com", role: "Witness", status: "Confirmed" },
  ]

  const guests = [
    { id: 101, name: "Emily Johnson", email: "emily@example.com", status: "Confirmed" },
    { id: 102, name: "David Wilson", email: "david@example.com", status: "Pending" },
    { id: 103, name: "Maria Garcia", email: "maria@example.com", status: "Confirmed" },
    { id: 104, name: "James Taylor", email: "james@example.com", status: "Declined" },
    { id: 105, name: "Jennifer Lee", email: "jennifer@example.com", status: "Pending" },
    { id: 106, name: "Michael Brown", email: "michael@example.com", status: "Confirmed" },
    { id: 107, name: "Lisa Martinez", email: "lisa@example.com", status: "Confirmed" },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="/dashboard" className="text-sm font-medium text-rose-600">
              Dashboard
            </Link>
            <Link href="/account" className="text-sm font-medium">
              Account
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Button variant="outline" size="sm">
              Log Out
            </Button>
          </div>
        </div>
      </header>
      <main className="flex-1 py-12">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-4">
            <div className="lg:col-span-1">
              <div className="space-y-4">
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold tracking-tight">Dashboard</h2>
                  <p className="text-muted-foreground">Manage your ceremony and participants</p>
                </div>
                <nav className="flex flex-col space-y-2">
                  <Button variant="ghost" className="justify-start" asChild>
                    <Link href="/dashboard">
                      <Calendar className="mr-2 h-4 w-4" />
                      Ceremony
                    </Link>
                  </Button>
                  <Button variant="ghost" className="justify-start bg-muted" asChild>
                    <Link href="/dashboard/participants">
                      <Users className="mr-2 h-4 w-4" />
                      Participants
                    </Link>
                  </Button>
                  <Button variant="ghost" className="justify-start" asChild>
                    <Link href="/dashboard/documents">
                      <FileText className="mr-2 h-4 w-4" />
                      Documents
                    </Link>
                  </Button>
                  <Button variant="ghost" className="justify-start" asChild>
                    <Link href="/dashboard/settings">
                      <Settings className="mr-2 h-4 w-4" />
                      Settings
                    </Link>
                  </Button>
                </nav>
              </div>
            </div>
            <div className="lg:col-span-3">
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-2xl font-bold">Participants & Guests</h2>
                  <Dialog open={showAddParticipant} onOpenChange={setShowAddParticipant}>
                    <DialogTrigger asChild>
                      <Button className="bg-rose-600 hover:bg-rose-700">
                        <Plus className="mr-2 h-4 w-4" />
                        Add Participant
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Add Participant</DialogTitle>
                        <DialogDescription>Add a new participant or guest to your ceremony.</DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid gap-2">
                          <Label htmlFor="name">Name</Label>
                          <Input id="name" placeholder="Enter full name" />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="email">Email</Label>
                          <Input id="email" type="email" placeholder="Enter email address" />
                        </div>
                        <div className="grid gap-2">
                          <Label htmlFor="role">Role</Label>
                          <Select>
                            <SelectTrigger id="role">
                              <SelectValue placeholder="Select role" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="witness">Witness</SelectItem>
                              <SelectItem value="guest">Guest</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline" onClick={() => setShowAddParticipant(false)}>
                          Cancel
                        </Button>
                        <Button className="bg-rose-600 hover:bg-rose-700" onClick={() => setShowAddParticipant(false)}>
                          Add Participant
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>

                <Card>
                  <CardHeader>
                    <CardTitle>Required Participants</CardTitle>
                    <CardDescription>
                      These participants are required for your ceremony to be legally valid
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {participants.map((participant) => (
                        <div key={participant.id} className="flex items-center justify-between rounded-lg border p-3">
                          <div className="space-y-1">
                            <p className="font-medium">{participant.name}</p>
                            <div className="flex items-center text-sm text-muted-foreground">
                              <Mail className="mr-1 h-3 w-3" />
                              {participant.email}
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <Badge
                              variant="outline"
                              className={
                                participant.status === "Confirmed"
                                  ? "bg-green-50 text-green-700"
                                  : participant.status === "Declined"
                                    ? "bg-red-50 text-red-700"
                                    : "bg-amber-50 text-amber-700"
                              }
                            >
                              {participant.status}
                            </Badge>
                            <div className="flex items-center">
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <Edit className="h-4 w-4" />
                                <span className="sr-only">Edit</span>
                              </Button>
                              {participant.role === "Witness" && (
                                <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500">
                                  <Trash2 className="h-4 w-4" />
                                  <span className="sr-only">Delete</span>
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0">
                    <div>
                      <CardTitle>Guests</CardTitle>
                      <CardDescription>Friends and family invited to your ceremony</CardDescription>
                    </div>
                    <Button variant="outline" size="sm">
                      <Mail className="mr-2 h-4 w-4" />
                      Send Reminder
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Input placeholder="Search guests..." className="w-[250px]" />
                          <Select>
                            <SelectTrigger className="w-[180px]">
                              <SelectValue placeholder="Filter by status" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="all">All Statuses</SelectItem>
                              <SelectItem value="confirmed">Confirmed</SelectItem>
                              <SelectItem value="pending">Pending</SelectItem>
                              <SelectItem value="declined">Declined</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {guests.filter((g) => g.status === "Confirmed").length} of {guests.length} confirmed
                        </div>
                      </div>

                      <div className="rounded-md border">
                        <div className="grid grid-cols-12 gap-4 p-3 font-medium border-b">
                          <div className="col-span-5">Name</div>
                          <div className="col-span-5">Email</div>
                          <div className="col-span-2">Status</div>
                        </div>
                        <div className="divide-y">
                          {guests.map((guest) => (
                            <div key={guest.id} className="grid grid-cols-12 gap-4 p-3 items-center">
                              <div className="col-span-5">{guest.name}</div>
                              <div className="col-span-5 text-sm text-muted-foreground">{guest.email}</div>
                              <div className="col-span-2">
                                <Badge
                                  variant="outline"
                                  className={
                                    guest.status === "Confirmed"
                                      ? "bg-green-50 text-green-700"
                                      : guest.status === "Declined"
                                        ? "bg-red-50 text-red-700"
                                        : "bg-amber-50 text-amber-700"
                                  }
                                >
                                  {guest.status}
                                </Badge>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="grid gap-4 md:grid-cols-2">
                  <Card>
                    <CardHeader>
                      <CardTitle>Bulk Actions</CardTitle>
                      <CardDescription>Manage multiple participants at once</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <Button variant="outline" className="w-full">
                          <Mail className="mr-2 h-4 w-4" />
                          Send Invitations
                        </Button>
                        <Button variant="outline" className="w-full">
                          <Users className="mr-2 h-4 w-4" />
                          Import Guests
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle>Ceremony Link</CardTitle>
                      <CardDescription>Share this link with your guests</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="flex">
                          <Input
                            readOnly
                            value="https://OnlineMarriagesNow.com/join/ceremony-12345"
                            className="rounded-r-none"
                          />
                          <Button className="rounded-l-none">Copy</Button>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          This link will be active 30 minutes before your ceremony starts.
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <footer className="w-full border-t bg-slate-50 py-6 md:py-12">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <div className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </div>
          <p className="text-center text-sm text-muted-foreground md:text-left">
            © {new Date().getFullYear()} OnlineMarriagesNow. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Link href="/terms" className="text-sm text-muted-foreground hover:underline">
              Terms
            </Link>
            <Link href="/privacy" className="text-sm text-muted-foreground hover:underline">
              Privacy
            </Link>
            <Link href="/contact" className="text-sm text-muted-foreground hover:underline">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
