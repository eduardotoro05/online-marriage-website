"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useParams } from "next/navigation"
import { Heart, Calendar, Video, Users, Clock, Download, LinkIcon } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"

export default function CeremonyDetailsPage() {
  const params = useParams()
  const ceremonyId = params.id as string
  const [isLoading, setIsLoading] = useState(true)
  const [ceremony, setCeremony] = useState<any>(null)

  useEffect(() => {
    // In a real app, you would fetch the ceremony details from your API
    // For this example, we'll use mock data
    const fetchCeremonyDetails = async () => {
      try {
        setIsLoading(true)

        // Simulate API call
        // const response = await fetch(`/api/ceremonies/${ceremonyId}`)
        // const data = await response.json()

        // Mock data
        const mockData = {
          id: ceremonyId,
          package: "Premium",
          status: "SCHEDULED",
          startTime: "2025-06-15T14:00:00Z",
          endTime: "2025-06-15T14:45:00Z",
          zoomMeetingId: "12345678901",
          zoomJoinUrl: "https://zoom.us/j/12345678901?pwd=abc123",
          zoomPassword: "abc123",
          participants: [
            { id: 1, name: "John Smith", email: "john@example.com", role: "PARTNER_1", status: "CONFIRMED" },
            { id: 2, name: "Jane Doe", email: "jane@example.com", role: "PARTNER_2", status: "CONFIRMED" },
            {
              id: 3,
              name: "Rev. Michael Johnson",
              email: "rev.michael@example.com",
              role: "OFFICIANT",
              status: "CONFIRMED",
            },
            { id: 4, name: "Sarah Williams", email: "sarah@example.com", role: "WITNESS", status: "PENDING" },
            { id: 5, name: "Robert Brown", email: "robert@example.com", role: "WITNESS", status: "CONFIRMED" },
          ],
          guests: [
            { id: 101, name: "Emily Johnson", email: "emily@example.com", status: "CONFIRMED" },
            { id: 102, name: "David Wilson", email: "david@example.com", status: "PENDING" },
            { id: 103, name: "Maria Garcia", email: "maria@example.com", status: "CONFIRMED" },
          ],
          recording: null, // Will be populated after ceremony
        }

        setCeremony(mockData)
        setIsLoading(false)
      } catch (err) {
        console.error("Error fetching ceremony details:", err)
        setIsLoading(false)
      }
    }

    fetchCeremonyDetails()
  }, [ceremonyId])

  if (isLoading) {
    return (
      <div className="flex min-h-screen flex-col">
        <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container flex h-16 items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Heart className="h-6 w-6 text-rose-500" />
              <span className="text-xl font-semibold">OnlineMarriagesNow</span>
            </Link>
          </div>
        </header>
        <main className="flex-1 py-12">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center py-12">
              <div className="h-12 w-12 animate-spin rounded-full border-4 border-rose-200 border-t-rose-600"></div>
              <p className="mt-4">Loading ceremony details...</p>
            </div>
          </div>
        </main>
      </div>
    )
  }

  if (!ceremony) {
    return (
      <div className="flex min-h-screen flex-col">
        <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container flex h-16 items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <Heart className="h-6 w-6 text-rose-500" />
              <span className="text-xl font-semibold">OnlineMarriagesNow</span>
            </Link>
          </div>
        </header>
        <main className="flex-1 py-12">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-md py-12">
              <Card>
                <CardHeader>
                  <CardTitle>Ceremony Not Found</CardTitle>
                  <CardDescription>
                    The ceremony you're looking for doesn't exist or you don't have access.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button asChild className="w-full">
                    <Link href="/dashboard">Return to Dashboard</Link>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    )
  }

  // Format date and time
  const ceremonyDate = new Date(ceremony.startTime)
  const formattedDate = ceremonyDate.toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  })
  const formattedTime = ceremonyDate.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" })

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="/dashboard" className="text-sm font-medium text-rose-600">
              Dashboard
            </Link>
            <Link href="/account" className="text-sm font-medium">
              Account
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Button variant="outline" size="sm" asChild>
              <Link href="/dashboard">Back to Dashboard</Link>
            </Button>
          </div>
        </div>
      </header>
      <main className="flex-1 py-12">
        <div className="container px-4 md:px-6">
          <div className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-3xl font-bold">Ceremony Details</h1>
              <p className="text-muted-foreground">
                {formattedDate} at {formattedTime}
              </p>
            </div>
            <div className="mt-4 flex items-center gap-2 md:mt-0">
              <Badge
                variant="outline"
                className={
                  ceremony.status === "COMPLETED"
                    ? "bg-green-50 text-green-700"
                    : ceremony.status === "CANCELED"
                      ? "bg-red-50 text-red-700"
                      : ceremony.status === "IN_PROGRESS"
                        ? "bg-blue-50 text-blue-700"
                        : "bg-amber-50 text-amber-700"
                }
              >
                {ceremony.status.replace("_", " ")}
              </Badge>
              <Badge variant="outline">{ceremony.package} Package</Badge>
            </div>
          </div>

          <div className="grid gap-6 md:grid-cols-3">
            <div className="md:col-span-2">
              <Tabs defaultValue="details" className="space-y-4">
                <TabsList>
                  <TabsTrigger value="details">Details</TabsTrigger>
                  <TabsTrigger value="participants">Participants</TabsTrigger>
                  <TabsTrigger value="recording">Recording</TabsTrigger>
                </TabsList>

                <TabsContent value="details">
                  <Card>
                    <CardHeader>
                      <CardTitle>Ceremony Information</CardTitle>
                      <CardDescription>Details about your scheduled ceremony</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="grid gap-4 md:grid-cols-2">
                        <div>
                          <h3 className="font-medium">Date & Time</h3>
                          <div className="mt-2 space-y-1">
                            <div className="flex items-center">
                              <Calendar className="mr-2 h-4 w-4 text-muted-foreground" />
                              <span>{formattedDate}</span>
                            </div>
                            <div className="flex items-center">
                              <Clock className="mr-2 h-4 w-4 text-muted-foreground" />
                              <span>{formattedTime}</span>
                            </div>
                          </div>
                        </div>
                        <div>
                          <h3 className="font-medium">Package Details</h3>
                          <div className="mt-2 space-y-1">
                            <div className="flex items-center">
                              <span className="text-muted-foreground">Package:</span>
                              <span className="ml-2 font-medium">{ceremony.package}</span>
                            </div>
                            <div className="flex items-center">
                              <span className="text-muted-foreground">Duration:</span>
                              <span className="ml-2 font-medium">
                                {ceremony.package === "Essential" ? "30" : ceremony.package === "Premium" ? "45" : "60"}{" "}
                                minutes
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="font-medium">Zoom Meeting Information</h3>
                        <div className="mt-2 space-y-4">
                          <div className="rounded-md bg-slate-50 p-4">
                            <div className="mb-2 flex items-center justify-between">
                              <span className="font-medium">Meeting ID:</span>
                              <span>{ceremony.zoomMeetingId}</span>
                            </div>
                            <div className="mb-2 flex items-center justify-between">
                              <span className="font-medium">Password:</span>
                              <span>{ceremony.zoomPassword}</span>
                            </div>
                          </div>

                          <div className="flex flex-col gap-2 sm:flex-row">
                            <Button className="flex-1 bg-rose-600 hover:bg-rose-700" asChild>
                              <Link href={`/join/${ceremonyId}`}>
                                <Video className="mr-2 h-4 w-4" />
                                Join Ceremony
                              </Link>
                            </Button>
                            <Button
                              variant="outline"
                              className="flex-1"
                              onClick={() => navigator.clipboard.writeText(ceremony.zoomJoinUrl)}
                            >
                              <LinkIcon className="mr-2 h-4 w-4" />
                              Copy Join Link
                            </Button>
                          </div>

                          <p className="text-xs text-muted-foreground">
                            The join button will be active 15 minutes before your scheduled time. You can also join
                            directly through Zoom using the Meeting ID and Password.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="participants">
                  <Card>
                    <CardHeader>
                      <CardTitle>Participants</CardTitle>
                      <CardDescription>People involved in your ceremony</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div>
                        <h3 className="font-medium">Required Participants</h3>
                        <div className="mt-2 space-y-2">
                          {ceremony.participants.map((participant: any) => (
                            <div
                              key={participant.id}
                              className="flex items-center justify-between rounded-md border p-3"
                            >
                              <div>
                                <p className="font-medium">{participant.name}</p>
                                <div className="flex items-center text-sm text-muted-foreground">
                                  <span>{participant.email}</span>
                                </div>
                              </div>
                              <div className="flex items-center gap-4">
                                <Badge
                                  variant="outline"
                                  className={
                                    participant.status === "CONFIRMED"
                                      ? "bg-green-50 text-green-700"
                                      : participant.status === "DECLINED"
                                        ? "bg-red-50 text-red-700"
                                        : "bg-amber-50 text-amber-700"
                                  }
                                >
                                  {participant.status}
                                </Badge>
                                <div className="rounded-md bg-slate-100 px-2 py-1 text-xs">
                                  {participant.role.replace("_", " ")}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center justify-between">
                          <h3 className="font-medium">Guests</h3>
                          <Badge variant="outline">{ceremony.guests.length} Invited</Badge>
                        </div>
                        <div className="mt-2 space-y-2">
                          {ceremony.guests.map((guest: any) => (
                            <div key={guest.id} className="flex items-center justify-between rounded-md border p-3">
                              <div>
                                <p className="font-medium">{guest.name}</p>
                                <div className="flex items-center text-sm text-muted-foreground">
                                  <span>{guest.email}</span>
                                </div>
                              </div>
                              <Badge
                                variant="outline"
                                className={
                                  guest.status === "CONFIRMED"
                                    ? "bg-green-50 text-green-700"
                                    : guest.status === "DECLINED"
                                      ? "bg-red-50 text-red-700"
                                      : "bg-amber-50 text-amber-700"
                                }
                              >
                                {guest.status}
                              </Badge>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="flex flex-col gap-2 sm:flex-row">
                        <Button variant="outline" className="flex-1">
                          <Users className="mr-2 h-4 w-4" />
                          Invite More Guests
                        </Button>
                        <Button variant="outline" className="flex-1">
                          Send Reminder to All
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="recording">
                  <Card>
                    <CardHeader>
                      <CardTitle>Ceremony Recording</CardTitle>
                      <CardDescription>Access your ceremony recording after the event</CardDescription>
                    </CardHeader>
                    <CardContent>
                      {ceremony.status === "COMPLETED" && ceremony.recording ? (
                        <div className="space-y-4">
                          <div className="aspect-video rounded-md bg-slate-100 flex items-center justify-center">
                            <video controls className="h-full w-full rounded-md">
                              <source src={ceremony.recording.url} type="video/mp4" />
                              Your browser does not support the video tag.
                            </video>
                          </div>
                          <div className="flex flex-col gap-2 sm:flex-row">
                            <Button className="flex-1" asChild>
                              <a href={ceremony.recording.url} download>
                                <Download className="mr-2 h-4 w-4" />
                                Download Recording
                              </a>
                            </Button>
                            <Button
                              variant="outline"
                              className="flex-1"
                              onClick={() => navigator.clipboard.writeText(ceremony.recording.url)}
                            >
                              <LinkIcon className="mr-2 h-4 w-4" />
                              Copy Link
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center justify-center py-12 text-center">
                          <Video className="mb-4 h-12 w-12 text-muted-foreground" />
                          <h3 className="text-lg font-medium">Recording Not Available Yet</h3>
                          <p className="mt-2 text-sm text-muted-foreground">
                            {ceremony.status === "COMPLETED"
                              ? "Your recording is being processed and will be available soon."
                              : "The recording will be available after your ceremony is completed."}
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>

            <div>
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Quick Actions</CardTitle>
                    <CardDescription>Manage your ceremony</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <Button className="w-full bg-rose-600 hover:bg-rose-700" asChild>
                        <Link href={`/join/${ceremonyId}`}>
                          <Video className="mr-2 h-4 w-4" />
                          Join Ceremony
                        </Link>
                      </Button>
                      <Button variant="outline" className="w-full">
                        <Calendar className="mr-2 h-4 w-4" />
                        Reschedule
                      </Button>
                      <Button variant="outline" className="w-full">
                        <Users className="mr-2 h-4 w-4" />
                        Manage Participants
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Share Ceremony</CardTitle>
                    <CardDescription>Invite others to your ceremony</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex">
                        <Input
                          readOnly
                          value={`https://onlinemarriagesnow.com/join/${ceremonyId}`}
                          className="rounded-r-none"
                        />
                        <Button
                          className="rounded-l-none"
                          onClick={() =>
                            navigator.clipboard.writeText(`https://onlinemarriagesnow.com/join/${ceremonyId}`)
                          }
                        >
                          Copy
                        </Button>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Share this link with guests who you'd like to invite to your ceremony.
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Support</CardTitle>
                    <CardDescription>Need help with your ceremony?</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <Button variant="outline" className="w-full">
                        Contact Your Officiant
                      </Button>
                      <Button variant="outline" className="w-full">
                        Technical Support
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </main>
      <footer className="w-full border-t bg-slate-50 py-6 md:py-12">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <div className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </div>
          <p className="text-center text-sm text-muted-foreground md:text-left">
            © {new Date().getFullYear()} OnlineMarriagesNow. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Link href="/terms" className="text-sm text-muted-foreground hover:underline">
              Terms
            </Link>
            <Link href="/privacy" className="text-sm text-muted-foreground hover:underline">
              Privacy
            </Link>
            <Link href="/contact" className="text-sm text-muted-foreground hover:underline">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
