"use client"

import { useState } from "react"
import Link from "next/link"
import { Heart, Calendar, Video, Users, Clock, FileText, Settings } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("upcoming")

  // Mock data - in a real app, this would come from your database
  const upcomingCeremony = {
    id: "CER-12345",
    date: "June 15, 2025",
    time: "2:00 PM",
    package: "Premium",
    status: "Confirmed",
    participants: [
      { name: "John Smith", role: "Partner 1", confirmed: true },
      { name: "Jane Doe", role: "Partner 2", confirmed: true },
      { name: "Rev. Michael Johnson", role: "Officiant", confirmed: true },
      { name: "Sarah Williams", role: "Witness", confirmed: false },
      { name: "Robert Brown", role: "Witness", confirmed: true },
    ],
    guests: 12,
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="/dashboard" className="text-sm font-medium text-rose-600">
              Dashboard
            </Link>
            <Link href="/account" className="text-sm font-medium">
              Account
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Button variant="outline" size="sm">
              Log Out
            </Button>
          </div>
        </div>
      </header>
      <main className="flex-1 py-12">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-4">
            <div className="lg:col-span-1">
              <div className="space-y-4">
                <div className="space-y-2">
                  <h2 className="text-2xl font-bold tracking-tight">Dashboard</h2>
                  <p className="text-muted-foreground">Manage your ceremony and participants</p>
                </div>
                <nav className="flex flex-col space-y-2">
                  <Button variant="ghost" className="justify-start" asChild>
                    <Link href="/dashboard">
                      <Calendar className="mr-2 h-4 w-4" />
                      Ceremony
                    </Link>
                  </Button>
                  <Button variant="ghost" className="justify-start" asChild>
                    <Link href="/dashboard/participants">
                      <Users className="mr-2 h-4 w-4" />
                      Participants
                    </Link>
                  </Button>
                  <Button variant="ghost" className="justify-start" asChild>
                    <Link href="/dashboard/documents">
                      <FileText className="mr-2 h-4 w-4" />
                      Documents
                    </Link>
                  </Button>
                  <Button variant="ghost" className="justify-start" asChild>
                    <Link href="/dashboard/settings">
                      <Settings className="mr-2 h-4 w-4" />
                      Settings
                    </Link>
                  </Button>
                </nav>
              </div>
            </div>
            <div className="lg:col-span-3">
              <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="space-y-4">
                <TabsList>
                  <TabsTrigger value="upcoming">Upcoming Ceremony</TabsTrigger>
                  <TabsTrigger value="past">Past Ceremonies</TabsTrigger>
                </TabsList>
                <TabsContent value="upcoming" className="space-y-4">
                  {upcomingCeremony ? (
                    <>
                      <Card>
                        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                          <div className="space-y-1">
                            <CardTitle>Your Upcoming Ceremony</CardTitle>
                            <CardDescription>All the details for your special day</CardDescription>
                          </div>
                          <Badge variant="outline" className="bg-green-50 text-green-700">
                            {upcomingCeremony.status}
                          </Badge>
                        </CardHeader>
                        <CardContent>
                          <div className="grid gap-4 md:grid-cols-2">
                            <div className="space-y-4">
                              <div>
                                <h3 className="font-medium">Ceremony Details</h3>
                                <div className="grid grid-cols-2 gap-2 pt-2">
                                  <div>
                                    <p className="text-sm text-muted-foreground">Date</p>
                                    <p className="font-medium">{upcomingCeremony.date}</p>
                                  </div>
                                  <div>
                                    <p className="text-sm text-muted-foreground">Time</p>
                                    <p className="font-medium">{upcomingCeremony.time}</p>
                                  </div>
                                  <div>
                                    <p className="text-sm text-muted-foreground">Package</p>
                                    <p className="font-medium">{upcomingCeremony.package}</p>
                                  </div>
                                  <div>
                                    <p className="text-sm text-muted-foreground">Ceremony ID</p>
                                    <p className="font-medium">{upcomingCeremony.id}</p>
                                  </div>
                                </div>
                              </div>
                              <div>
                                <h3 className="font-medium">Join Information</h3>
                                <div className="mt-2 space-y-2">
                                  <Button className="w-full bg-rose-600 hover:bg-rose-700">
                                    <Video className="mr-2 h-4 w-4" />
                                    Join Ceremony
                                  </Button>
                                  <p className="text-xs text-muted-foreground">
                                    The join button will be active 15 minutes before your scheduled time.
                                  </p>
                                </div>
                              </div>
                            </div>
                            <div className="space-y-4">
                              <div>
                                <h3 className="font-medium">Participants</h3>
                                <div className="mt-2 space-y-2">
                                  {upcomingCeremony.participants.map((participant, index) => (
                                    <div
                                      key={index}
                                      className="flex items-center justify-between rounded-md border p-2"
                                    >
                                      <div>
                                        <p className="text-sm font-medium">{participant.name}</p>
                                        <p className="text-xs text-muted-foreground">{participant.role}</p>
                                      </div>
                                      <Badge
                                        variant="outline"
                                        className={
                                          participant.confirmed
                                            ? "bg-green-50 text-green-700"
                                            : "bg-amber-50 text-amber-700"
                                        }
                                      >
                                        {participant.confirmed ? "Confirmed" : "Pending"}
                                      </Badge>
                                    </div>
                                  ))}
                                </div>
                              </div>
                              <div>
                                <div className="flex items-center justify-between">
                                  <h3 className="font-medium">Guests</h3>
                                  <Badge variant="outline">{upcomingCeremony.guests} Invited</Badge>
                                </div>
                                <div className="mt-2">
                                  <Button variant="outline" className="w-full">
                                    <Users className="mr-2 h-4 w-4" />
                                    Manage Guest List
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="mt-6 space-y-2">
                            <h3 className="font-medium">Upcoming Steps</h3>
                            <div className="space-y-2">
                              <div className="flex items-start space-x-2">
                                <Clock className="mt-0.5 h-4 w-4 text-muted-foreground" />
                                <div>
                                  <p className="text-sm font-medium">Pre-Ceremony Check</p>
                                  <p className="text-xs text-muted-foreground">
                                    June 14, 2025 at 2:00 PM - Test your video and audio setup
                                  </p>
                                </div>
                              </div>
                              <div className="flex items-start space-x-2">
                                <FileText className="mt-0.5 h-4 w-4 text-muted-foreground" />
                                <div>
                                  <p className="text-sm font-medium">Document Verification</p>
                                  <p className="text-xs text-muted-foreground">
                                    Please upload your identification documents by June 10, 2025
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      <div className="grid gap-4 md:grid-cols-2">
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle>Scheduling</CardTitle>
                            <CardDescription>Manage ceremony time and participants</CardDescription>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-4">
                              <Button variant="outline" className="w-full">
                                <Calendar className="mr-2 h-4 w-4" />
                                Reschedule Ceremony
                              </Button>
                              <Button variant="outline" className="w-full">
                                <Users className="mr-2 h-4 w-4" />
                                Add/Remove Participants
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardHeader className="pb-2">
                            <CardTitle>Documents</CardTitle>
                            <CardDescription>Marriage application status</CardDescription>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-4">
                              <div className="flex items-center justify-between">
                                <div>
                                  <p className="text-sm font-medium">Application Process</p>
                                  <p className="text-xs text-muted-foreground">Step 2 of 7</p>
                                </div>
                                <Badge variant="outline" className="bg-amber-50 text-amber-700">
                                  In Progress
                                </Badge>
                              </div>
                              <Progress value={28} className="h-2" />
                              <Button variant="outline" className="w-full" asChild>
                                <Link href="/dashboard/documents">
                                  <FileText className="mr-2 h-4 w-4" />
                                  Manage Documents
                                </Link>
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </>
                  ) : (
                    <Card>
                      <CardHeader>
                        <CardTitle>No Upcoming Ceremonies</CardTitle>
                        <CardDescription>You don't have any ceremonies scheduled</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Button asChild>
                          <Link href="/booking">Book a Ceremony</Link>
                        </Button>
                      </CardContent>
                    </Card>
                  )}
                </TabsContent>
                <TabsContent value="past">
                  <Card>
                    <CardHeader>
                      <CardTitle>Past Ceremonies</CardTitle>
                      <CardDescription>View your ceremony history</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-center py-6 text-muted-foreground">No past ceremonies found</p>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </main>
      <footer className="w-full border-t bg-slate-50 py-6 md:py-12">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <div className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </div>
          <p className="text-center text-sm text-muted-foreground md:text-left">
            © {new Date().getFullYear()} OnlineMarriagesNow. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Link href="/terms" className="text-sm text-muted-foreground hover:underline">
              Terms
            </Link>
            <Link href="/privacy" className="text-sm text-muted-foreground hover:underline">
              Privacy
            </Link>
            <Link href="/contact" className="text-sm text-muted-foreground hover:underline">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
