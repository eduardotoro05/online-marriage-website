"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Heart } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function ZoomJoinPage({ params }: { params: { ceremonyId: string } }) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [meetingDetails, setMeetingDetails] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const [userDetails, setUserDetails] = useState({
    name: "",
    email: "",
  })

  useEffect(() => {
    // In a real app, you would fetch the meeting details from your API
    // For this example, we'll use mock data
    const fetchMeetingDetails = async () => {
      try {
        setIsLoading(true)

        // Simulate API call
        // const response = await fetch(`/api/ceremonies/${params.ceremonyId}/meeting`)
        // const data = await response.json()

        // Mock data
        const mockData = {
          meetingNumber: "12345678901",
          password: "password123",
          topic: "John & Jane's Wedding Ceremony",
          startTime: new Date(Date.now() + 10 * 60 * 1000).toISOString(), // 10 minutes from now
          status: "waiting",
        }

        setMeetingDetails(mockData)

        // Get user details (in a real app, from your auth system)
        setUserDetails({
          name: "Guest User",
          email: "guest@example.com",
        })

        setIsLoading(false)
      } catch (err) {
        console.error("Error fetching meeting details:", err)
        setError("Failed to load ceremony details. Please try again.")
        setIsLoading(false)
      }
    }

    fetchMeetingDetails()
  }, [params.ceremonyId])

  const joinWithBrowser = () => {
    router.push(`/join/${params.ceremonyId}`)
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </Link>
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium">Ceremony ID: {params.ceremonyId}</span>
          </div>
        </div>
      </header>
      <main className="flex-1 py-12">
        <div className="container px-4 md:px-6">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-12">
              <div className="h-12 w-12 animate-spin rounded-full border-4 border-rose-200 border-t-rose-600"></div>
              <p className="mt-4">Loading ceremony details...</p>
            </div>
          ) : error ? (
            <div className="mx-auto max-w-md py-12">
              <Card>
                <CardHeader>
                  <CardTitle>Error</CardTitle>
                  <CardDescription>{error}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button onClick={() => window.location.reload()} className="w-full">
                    Try Again
                  </Button>
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="mx-auto max-w-4xl">
              <div className="mb-8">
                <h1 className="text-2xl font-bold">{meetingDetails.topic}</h1>
                <p className="text-muted-foreground">
                  You can join this ceremony using Zoom or directly in your browser
                </p>
              </div>

              <div className="grid gap-6 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Join with Zoom App</CardTitle>
                    <CardDescription>
                      For the best experience, join using the Zoom desktop or mobile app
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="rounded-md bg-slate-50 p-4">
                        <p className="font-medium">Meeting ID: {meetingDetails.meetingNumber}</p>
                        <p className="font-medium">Password: {meetingDetails.password}</p>
                      </div>
                      <Button
                        className="w-full bg-blue-600 hover:bg-blue-700"
                        onClick={() => {
                          window.open(
                            `zoommtg://zoom.us/join?confno=${meetingDetails.meetingNumber}&pwd=${meetingDetails.password}&zc=0&uname=${encodeURIComponent(userDetails.name)}`,
                            "_blank",
                          )
                        }}
                      >
                        Open in Zoom App
                      </Button>
                      <p className="text-xs text-center text-muted-foreground">
                        This will open the Zoom application if installed
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Join in Browser</CardTitle>
                    <CardDescription>Join directly in your web browser without installing anything</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <p className="text-sm">
                        You'll join as: <span className="font-medium">{userDetails.name}</span>
                      </p>
                      <Button onClick={joinWithBrowser} className="w-full bg-rose-600 hover:bg-rose-700">
                        Join in Browser
                      </Button>
                      <p className="text-xs text-center text-muted-foreground">
                        For the best experience, use Chrome or Firefox
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* This would be used if implementing the Zoom Web SDK directly on this page */}
              {/* <div className="mt-8">
                <ZoomMeetingEmbed
                  meetingNumber={meetingDetails.meetingNumber}
                  passWord={meetingDetails.password}
                  userName={userDetails.name}
                  userEmail={userDetails.email}
                  leaveUrl={`/dashboard`}
                  className="min-h-[600px] w-full border rounded-md"
                />
              </div> */}
            </div>
          )}
        </div>
      </main>
      <footer className="w-full border-t py-4">
        <div className="container flex items-center justify-between">
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} OnlineMarriagesNow. All rights reserved.
          </p>
          <p className="text-xs text-muted-foreground">
            Having technical issues?{" "}
            <Link href="/support" className="underline">
              Get help
            </Link>
          </p>
        </div>
      </footer>
    </div>
  )
}
