"use client"

import { useState } from "react"
import Link from "next/link"
import { Heart, Video, Mic, MicOff, VideoOff, Users, MessageSquare, Phone } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"

export default function CeremonyPage({ params }: { params: { ceremonyId: string } }) {
  const [isJoined, setIsJoined] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [isVideoOff, setIsVideoOff] = useState(false)
  const [activeTab, setActiveTab] = useState("video")
  const [messages, setMessages] = useState([
    { id: 1, sender: "System", content: "Welcome to the ceremony! It will begin shortly." },
    {
      id: 2,
      sender: "Rev. Michael Johnson",
      content:
        "I'll be starting the ceremony in about 5 minutes. Please make sure your audio and video are working properly.",
    },
    { id: 3, sender: "John Smith", content: "We're so excited to have everyone here with us today!" },
  ])
  const [newMessage, setNewMessage] = useState("")

  const sendMessage = () => {
    if (newMessage.trim()) {
      setMessages([...messages, { id: messages.length + 1, sender: "You", content: newMessage }])
      setNewMessage("")
    }
  }

  // Mock data for participants
  const participants = [
    { id: 1, name: "John Smith", role: "Partner 1", isYou: false },
    { id: 2, name: "Jane Doe", role: "Partner 2", isYou: false },
    { id: 3, name: "Rev. Michael Johnson", role: "Officiant", isYou: false },
    { id: 4, name: "Sarah Williams", role: "Witness", isYou: false },
    { id: 5, name: "Robert Brown", role: "Witness", isYou: false },
    { id: 6, name: "You", role: "Guest", isYou: true },
    { id: 7, name: "Emily Johnson", role: "Guest", isYou: false },
    { id: 8, name: "David Wilson", role: "Guest", isYou: false },
  ]

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </Link>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="bg-green-50 text-green-700">
              Live Ceremony
            </Badge>
            <span className="text-sm font-medium">Ceremony ID: {params.ceremonyId}</span>
          </div>
        </div>
      </header>
      <main className="flex-1 py-4">
        <div className="container px-4 md:px-6">
          {!isJoined ? (
            <div className="mx-auto max-w-md py-12">
              <Card>
                <CardHeader>
                  <CardTitle>Join the Ceremony</CardTitle>
                  <CardDescription>You're about to join the wedding ceremony of John & Jane</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="aspect-video rounded-md bg-slate-100 flex items-center justify-center">
                      <Video className="h-12 w-12 text-slate-400" />
                    </div>
                    <p className="text-sm text-center text-muted-foreground">
                      Your camera and microphone will be enabled when you join
                    </p>
                    <Button onClick={() => setIsJoined(true)} className="w-full bg-rose-600 hover:bg-rose-700">
                      <Video className="mr-2 h-4 w-4" />
                      Join Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-4">
              <div className="md:col-span-3">
                <div className="space-y-4">
                  <div className="aspect-video rounded-md bg-slate-900 relative overflow-hidden">
                    <div className="absolute inset-0 grid grid-cols-2 grid-rows-2 gap-1 p-1">
                      <div className="relative col-span-2 row-span-2 rounded bg-slate-800 flex items-center justify-center">
                        <Video className="h-16 w-16 text-slate-600" />
                        <div className="absolute bottom-2 left-2 bg-black/50 px-2 py-1 rounded text-white text-xs">
                          Rev. Michael Johnson (Officiant)
                        </div>
                      </div>
                      <div className="absolute top-2 right-2 flex space-x-1">
                        <div className="rounded bg-slate-800 p-1 w-32 h-24 flex items-center justify-center">
                          <Video className="h-8 w-8 text-slate-600" />
                          <div className="absolute bottom-1 left-1 bg-black/50 px-1 rounded text-white text-[10px]">
                            John Smith
                          </div>
                        </div>
                        <div className="rounded bg-slate-800 p-1 w-32 h-24 flex items-center justify-center">
                          <Video className="h-8 w-8 text-slate-600" />
                          <div className="absolute bottom-1 left-1 bg-black/50 px-1 rounded text-white text-[10px]">
                            Jane Doe
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center justify-center space-x-2">
                    <Button
                      variant="outline"
                      size="icon"
                      className={isMuted ? "bg-red-100 text-red-700 border-red-200" : ""}
                      onClick={() => setIsMuted(!isMuted)}
                    >
                      {isMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      className={isVideoOff ? "bg-red-100 text-red-700 border-red-200" : ""}
                      onClick={() => setIsVideoOff(!isVideoOff)}
                    >
                      {isVideoOff ? <VideoOff className="h-5 w-5" /> : <Video className="h-5 w-5" />}
                    </Button>
                    <Button variant="destructive" size="icon">
                      <Phone className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              </div>
              <div className="md:col-span-1">
                <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="participants">
                      <Users className="mr-2 h-4 w-4" />
                      People
                    </TabsTrigger>
                    <TabsTrigger value="chat">
                      <MessageSquare className="mr-2 h-4 w-4" />
                      Chat
                    </TabsTrigger>
                  </TabsList>
                  <TabsContent value="participants" className="flex-1 border rounded-md mt-2 overflow-auto">
                    <div className="p-4 space-y-4">
                      <div>
                        <h3 className="text-sm font-medium mb-2">Ceremony Participants</h3>
                        <div className="space-y-2">
                          {participants
                            .filter((p) => p.role !== "Guest")
                            .map((participant) => (
                              <div
                                key={participant.id}
                                className="flex items-center justify-between rounded-md border p-2"
                              >
                                <div className="flex items-center">
                                  <div className="h-6 w-6 rounded-full bg-slate-200 mr-2"></div>
                                  <div>
                                    <p className="text-sm font-medium">
                                      {participant.name}
                                      {participant.isYou && " (You)"}
                                    </p>
                                    <p className="text-xs text-muted-foreground">{participant.role}</p>
                                  </div>
                                </div>
                              </div>
                            ))}
                        </div>
                      </div>
                      <Separator />
                      <div>
                        <h3 className="text-sm font-medium mb-2">
                          Guests ({participants.filter((p) => p.role === "Guest").length})
                        </h3>
                        <div className="space-y-2">
                          {participants
                            .filter((p) => p.role === "Guest")
                            .map((participant) => (
                              <div
                                key={participant.id}
                                className="flex items-center justify-between rounded-md border p-2"
                              >
                                <div className="flex items-center">
                                  <div className="h-6 w-6 rounded-full bg-slate-200 mr-2"></div>
                                  <div>
                                    <p className="text-sm font-medium">
                                      {participant.name}
                                      {participant.isYou && " (You)"}
                                    </p>
                                  </div>
                                </div>
                              </div>
                            ))}
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                  <TabsContent value="chat" className="flex-1 border rounded-md mt-2 flex flex-col">
                    <div className="flex-1 p-4 overflow-auto space-y-4">
                      {messages.map((message) => (
                        <div key={message.id} className="space-y-1">
                          <p className="text-xs font-medium">{message.sender}</p>
                          <div className="rounded-md bg-slate-100 p-2">
                            <p className="text-sm">{message.content}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="p-4 border-t">
                      <div className="flex space-x-2">
                        <Input
                          placeholder="Type a message..."
                          value={newMessage}
                          onChange={(e) => setNewMessage(e.target.value)}
                          onKeyDown={(e) => e.key === "Enter" && sendMessage()}
                        />
                        <Button onClick={sendMessage}>Send</Button>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          )}
        </div>
      </main>
      <footer className="w-full border-t py-2">
        <div className="container flex items-center justify-between">
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} OnlineMarriagesNow. All rights reserved.
          </p>
          <p className="text-xs text-muted-foreground">
            Having technical issues?{" "}
            <Link href="/support" className="underline">
              Get help
            </Link>
          </p>
        </div>
      </footer>
    </div>
  )
}
