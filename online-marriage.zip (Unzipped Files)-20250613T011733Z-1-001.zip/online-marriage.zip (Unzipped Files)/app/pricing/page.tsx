import Link from "next/link"
import { ArrowRight, Check, Heart, Plus } from "lucide-react"

import { Button } from "@/components/ui/button"

export default function PricingPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/" className="text-sm font-medium">
              Home
            </Link>
            <Link href="/how-it-works" className="text-sm font-medium">
              How It Works
            </Link>
            <Link href="/faq" className="text-sm font-medium">
              FAQ
            </Link>
            <Link href="/pricing" className="text-sm font-medium text-rose-600">
              Pricing
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="/booking">
              <Button>Get Married Now</Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="mx-auto max-w-4xl space-y-8">
              <div className="space-y-2 text-center">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Simple, Transparent Pricing
                </h1>
                <p className="text-muted-foreground md:text-xl">
                  One price for everything you need, add only what you want
                </p>
              </div>

              {/* Main Package */}
              <div className="flex justify-center">
                <div className="w-full max-w-lg rounded-lg border-2 border-rose-200 bg-rose-50 p-8 shadow-lg">
                  <div className="text-center">
                    <h2 className="text-2xl font-bold mb-2">Online Marriage Ceremony</h2>
                    <div className="mb-4">
                      <span className="text-5xl font-bold text-rose-600">$299</span>
                      <span className="text-muted-foreground ml-2">one-time</span>
                    </div>
                    <p className="text-muted-foreground mb-6">Everything you need for a legal marriage ceremony</p>

                    <div className="space-y-3 text-left mb-8">
                      <div className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                        <span>Licensed officiant</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                        <span>Legal marriage certificate</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                        <span>30-minute ceremony</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                        <span>Invite unlimited guests</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                        <span>Choose your own vows or use ours</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                        <span>Ceremony recording</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                        <span>Digital certificate copy</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                        <span>Email support</span>
                      </div>
                    </div>

                    <Link href="/booking">
                      <Button size="lg" className="w-full bg-rose-600 hover:bg-rose-700">
                        Book Your Ceremony
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>

              {/* Add-ons */}
              <div className="space-y-6">
                <div className="text-center">
                  <h2 className="text-2xl font-bold mb-2">Optional Add-ons</h2>
                  <p className="text-muted-foreground">Customize your ceremony with these optional extras</p>
                </div>

                <div className="grid gap-6 md:grid-cols-3">
                  <div className="rounded-lg border p-6 text-center hover:shadow-md transition-shadow">
                    <div className="mb-4">
                      <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-blue-100 mb-3">
                        <Plus className="h-6 w-6 text-blue-600" />
                      </div>
                      <h3 className="text-lg font-semibold">Same-Day Ceremony</h3>
                    </div>
                    <div className="mb-4">
                      <span className="text-3xl font-bold text-blue-600">+$200</span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      Get married today! Perfect for urgent situations or when you can't wait.
                    </p>
                    <div className="text-xs text-muted-foreground bg-blue-50 p-2 rounded">
                      Subject to officiant availability
                    </div>
                  </div>

                  <div className="rounded-lg border p-6 text-center hover:shadow-md transition-shadow">
                    <div className="mb-4">
                      <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-green-100 mb-3">
                        <Plus className="h-6 w-6 text-green-600" />
                      </div>
                      <h3 className="text-lg font-semibold">Witnesses Provided</h3>
                    </div>
                    <div className="mb-4">
                      <span className="text-3xl font-bold text-green-600">+$25</span>
                      <div className="text-sm text-muted-foreground">per witness</div>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      We'll provide professional witnesses if your state requires them or you need extras.
                    </p>
                    <div className="text-xs text-muted-foreground bg-green-50 p-2 rounded">
                      Most states require 1-2 witnesses
                    </div>
                  </div>

                  <div className="rounded-lg border p-6 text-center hover:shadow-md transition-shadow">
                    <div className="mb-4">
                      <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-purple-100 mb-3">
                        <Plus className="h-6 w-6 text-purple-600" />
                      </div>
                      <h3 className="text-lg font-semibold">Apostille Stamp</h3>
                    </div>
                    <div className="mb-4">
                      <span className="text-3xl font-bold text-purple-600">+$150</span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-4">
                      International authentication for your marriage certificate for use abroad.
                    </p>
                    <div className="text-xs text-muted-foreground bg-purple-50 p-2 rounded">
                      Required for international recognition
                    </div>
                  </div>
                </div>
              </div>

              {/* FAQ Section */}
              <div className="space-y-4 text-center">
                <h2 className="text-2xl font-bold">Frequently Asked Questions</h2>
                <div className="grid gap-4 md:grid-cols-2 text-left">
                  <div className="rounded-lg border p-4">
                    <h3 className="mb-2 font-semibold">Are there any hidden fees?</h3>
                    <p className="text-sm text-muted-foreground">
                      No hidden fees. $299 includes everything for your ceremony. Add-ons are clearly priced and
                      optional.
                    </p>
                  </div>
                  <div className="rounded-lg border p-4">
                    <h3 className="mb-2 font-semibold">Can I add extras later?</h3>
                    <p className="text-sm text-muted-foreground">
                      Yes, you can add same-day ceremony, witnesses, or apostille stamp anytime before your ceremony.
                    </p>
                  </div>
                  <div className="rounded-lg border p-4">
                    <h3 className="mb-2 font-semibold">What payment methods do you accept?</h3>
                    <p className="text-sm text-muted-foreground">
                      We accept all major credit cards, PayPal, and bank transfers. Payment is processed securely
                      through Stripe.
                    </p>
                  </div>
                  <div className="rounded-lg border p-4">
                    <h3 className="mb-2 font-semibold">What's your refund policy?</h3>
                    <p className="text-sm text-muted-foreground">
                      Full refunds available up to 7 days before your ceremony. 50% refund for cancellations within 7
                      days.
                    </p>
                  </div>
                </div>
              </div>

              {/* CTA */}
              <div className="text-center space-y-4">
                <h2 className="text-2xl font-bold">Ready to Get Started?</h2>
                <p className="text-muted-foreground">Join thousands of couples who have chosen OnlineMarriagesNow</p>
                <Link href="/booking">
                  <Button size="lg" className="bg-rose-600 hover:bg-rose-700">
                    Book Your Ceremony - $299
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="w-full border-t bg-slate-50 py-6 md:py-12">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <div className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-rose-500" />
            <span className="text-xl font-semibold">OnlineMarriagesNow</span>
          </div>
          <p className="text-center text-sm text-muted-foreground md:text-left">
            © {new Date().getFullYear()} OnlineMarriagesNow. All rights reserved.
          </p>
          <div className="flex gap-4">
            <Link href="/terms" className="text-sm text-muted-foreground hover:underline">
              Terms
            </Link>
            <Link href="/privacy" className="text-sm text-muted-foreground hover:underline">
              Privacy
            </Link>
            <Link href="/contact" className="text-sm text-muted-foreground hover:underline">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
