import { NextResponse } from "next/server"

export async function GET() {
  try {
    // Get SDK key from environment variables
    const sdkKey = process.env.ZOOM_SDK_KEY

    if (!sdkKey) {
      throw new Error("Zoom SDK key not configured")
    }

    return NextResponse.json({ sdkKey })
  } catch (error) {
    console.error("Error getting Zoom SDK key:", error)
    return NextResponse.json({ error: "Failed to get Zoom SDK key" }, { status: 500 })
  }
}
