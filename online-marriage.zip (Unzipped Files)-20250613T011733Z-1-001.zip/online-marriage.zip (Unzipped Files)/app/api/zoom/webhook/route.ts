import { NextResponse } from "next/server"

// This endpoint will receive webhook events from Zoom
export async function POST(req: Request) {
  try {
    const body = await req.json()

    // Verify webhook signature (recommended for production)
    // const signature = req.headers.get('x-zm-signature')
    // verifyZoomWebhookSignature(signature, body, process.env.ZOOM_WEBHOOK_SECRET)

    const { event, payload } = body

    // Handle different event types
    switch (event) {
      case "meeting.started": {
        // Meeting has started
        const { object } = payload
        const meetingId = object.id

        // Update ceremony status in your database
        // await db.ceremonies.update({
        //   where: { zoomMeetingId: meetingId },
        //   data: { status: 'IN_PROGRESS' }
        // })

        console.log("Meeting started:", meetingId)
        break
      }

      case "meeting.ended": {
        // Meeting has ended
        const { object } = payload
        const meetingId = object.id

        // Update ceremony status in your database
        // await db.ceremonies.update({
        //   where: { zoomMeetingId: meetingId },
        //   data: { status: 'COMPLETED' }
        // })

        // Process recording when available
        // setTimeout(async () => {
        //   await processZoomRecording(meetingId)
        // }, 10 * 60 * 1000) // Wait 10 minutes for recording to process

        console.log("Meeting ended:", meetingId)
        break
      }

      case "recording.completed": {
        // Recording is available
        const { object } = payload
        const meetingId = object.id
        const recordingFiles = object.recording_files

        // Store recording information in your database
        // await db.ceremonies.update({
        //   where: { zoomMeetingId: meetingId },
        //   data: {
        //     recordingUrl: recordingFiles[0].download_url,
        //     recordingPassword: object.password
        //   }
        // })

        // Send email to couple with recording link
        // const ceremony = await db.ceremonies.findUnique({ where: { zoomMeetingId: meetingId } })
        // await sendRecordingEmail(ceremony)

        console.log("Recording available:", meetingId)
        break
      }
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Zoom webhook error:", error)
    return NextResponse.json({ error: "Failed to process webhook" }, { status: 500 })
  }
}
