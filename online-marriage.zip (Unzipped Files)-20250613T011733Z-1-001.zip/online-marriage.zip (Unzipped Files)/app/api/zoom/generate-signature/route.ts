import { NextResponse } from "next/server"
import crypto from "crypto"

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { meetingNumber, role } = body

    // Get SDK key and secret from environment variables
    const sdkKey = process.env.ZOOM_SDK_KEY
    const sdkSecret = process.env.ZOOM_SDK_SECRET

    if (!sdkKey || !sdkSecret) {
      throw new Error("Zoom SDK credentials not configured")
    }

    // Generate timestamp
    const timestamp = new Date().getTime() - 30000

    // Generate signature
    const msg = Buffer.from(sdkKey + meetingNumber + timestamp + role).toString()
    const hash = crypto.createHmac("sha256", sdkSecret).update(msg).digest("base64")
    const signature = Buffer.from(`${sdkKey}.${meetingNumber}.${timestamp}.${role}.${hash}`).toString("base64")

    return NextResponse.json({ signature })
  } catch (error) {
    console.error("Error generating Zoom signature:", error)
    return NextResponse.json({ error: "Failed to generate signature" }, { status: 500 })
  }
}
