import { NextResponse } from "next/server"
import { createZoomMeeting } from "@/lib/zoom-client"

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { topic, startTime, duration, agenda, participants } = body

    // Create the Zoom meeting
    const meeting = await createZoomMeeting({
      topic,
      startTime,
      duration,
      agenda,
    })

    // In a real app, you would store the meeting details in your database
    // and associate it with the ceremony

    // Return the meeting details
    return NextResponse.json({
      success: true,
      meeting: {
        id: meeting.id,
        join_url: meeting.join_url,
        start_url: meeting.start_url,
        password: meeting.password,
        start_time: meeting.start_time,
      },
    })
  } catch (error) {
    console.error("Error creating Zoom meeting:", error)
    return NextResponse.json({ error: "Failed to create Zoom meeting" }, { status: 500 })
  }
}
