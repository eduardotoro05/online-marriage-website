import { NextResponse } from "next/server"
import sgMail from "@sendgrid/mail"

export async function GET() {
  try {
    console.log("=== TESTING EMAIL SERVICE ===")
    console.log("SendGrid API Key exists:", !!process.env.SENDGRID_API_KEY)
    console.log("SendGrid API Key length:", process.env.SENDGRID_API_KEY?.length || 0)

    if (!process.env.SENDGRID_API_KEY) {
      return NextResponse.json({
        success: false,
        error: "SENDGRID_API_KEY not configured",
      })
    }

    // Initialize SendGrid
    sgMail.setApiKey(process.env.SENDGRID_API_KEY)

    // Send a simple test email
    const msg = {
      to: "test@example.com", // Replace with your email
      from: "noreply@onlinemarriagesnow.com", // This needs to be verified in SendGrid
      subject: "Test Email from OnlineMarriagesNow",
      text: "This is a test email to verify SendGrid is working.",
      html: "<p>This is a test email to verify SendGrid is working.</p>",
    }

    await sgMail.send(msg)
    console.log("✅ Test email sent successfully!")

    return NextResponse.json({
      success: true,
      message: "Test email sent successfully",
    })
  } catch (error) {
    console.error("❌ Email test failed:", error)
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
        details: error,
      },
      { status: 500 },
    )
  }
}
