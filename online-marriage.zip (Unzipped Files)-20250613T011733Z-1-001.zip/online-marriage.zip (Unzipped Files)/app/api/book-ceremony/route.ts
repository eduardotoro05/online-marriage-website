import { NextResponse } from "next/server"
import { sendBookingConfirmation } from "@/lib/email-service"
import { createZoomMeeting } from "@/lib/zoom-client"

export async function POST(req: Request) {
  try {
    console.log("=== BOOKING API CALLED ===")
    const body = await req.json()
    console.log("Received booking data:", JSON.stringify(body, null, 2))

    const {
      package: selectedPackage,
      packageName,
      originalPrice,
      finalPrice,
      discount,
      promoCode,
      date,
      time,
      participants,
      address,
    } = body

    console.log("Extracted data:", {
      selectedPackage,
      packageName,
      originalPrice,
      finalPrice,
      discount,
      promoCode,
      date,
      time,
      participantsCount: participants?.length,
    })

    // Generate a unique booking ID
    const bookingId = `OMN-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
    console.log("Generated booking ID:", bookingId)

    // Extract partner information
    const partnerOne = participants?.[0]
    const partnerTwo = participants?.[1]

    console.log("Partner info:", {
      partnerOne: partnerOne ? `${partnerOne.firstName} ${partnerOne.lastName} (${partnerOne.email})` : "Missing",
      partnerTwo: partnerTwo ? `${partnerTwo.firstName} ${partnerTwo.lastName} (${partnerTwo.email})` : "Missing",
    })

    // Create Zoom meeting for the ceremony
    let zoomMeeting = null
    try {
      console.log("=== CREATING ZOOM MEETING ===")
      if (date && time) {
        // Convert date and time to proper DateTime
        const ceremonyDate = new Date(date)
        const [timeStr, period] = time.split(" ")
        const [hours, minutes] = timeStr.split(":")
        let hour24 = Number.parseInt(hours)

        if (period === "PM" && hour24 !== 12) {
          hour24 += 12
        } else if (period === "AM" && hour24 === 12) {
          hour24 = 0
        }

        ceremonyDate.setHours(hour24, Number.parseInt(minutes), 0, 0)

        zoomMeeting = await createZoomMeeting({
          topic: `Wedding Ceremony - ${partnerOne?.firstName} & ${partnerTwo?.firstName}`,
          start_time: ceremonyDate.toISOString(),
          duration: 60, // 1 hour
          settings: {
            join_before_host: true,
            waiting_room: false,
            mute_participants_upon_entry: false,
          },
        })
        console.log("Zoom meeting created successfully:", zoomMeeting?.id)
      } else {
        console.log("No date/time provided, skipping Zoom meeting creation")
      }
    } catch (zoomError) {
      console.error("Failed to create Zoom meeting:", zoomError)
      // Continue with booking even if Zoom fails
    }

    // Create booking data with proper structure for email service
    const bookingData = {
      id: bookingId,
      partnerOne: {
        firstName: partnerOne?.firstName || "",
        lastName: partnerOne?.lastName || "",
        email: partnerOne?.email || "",
        phone: partnerOne?.phone || "",
      },
      partnerTwo: {
        firstName: partnerTwo?.firstName || "",
        lastName: partnerTwo?.lastName || "",
        email: partnerTwo?.email || "",
        phone: partnerTwo?.phone || "",
      },
      package: {
        name: packageName || selectedPackage?.name || "Wedding Package",
        price: originalPrice || selectedPackage?.price || 0,
      },
      ceremonyDate: date,
      ceremonyTime: time,
      finalAmount: finalPrice || 0,
      promoCode: promoCode || undefined,
      zoomMeeting: zoomMeeting
        ? {
            id: zoomMeeting.id,
            join_url: zoomMeeting.join_url,
            password: zoomMeeting.password,
          }
        : undefined,
      status: "confirmed",
      createdAt: new Date().toISOString(),
    }

    console.log("=== SENDING CONFIRMATION EMAILS ===")
    console.log("Email data prepared for:", {
      partnerOneEmail: partnerOne?.email,
      partnerTwoEmail: partnerTwo?.email,
      bookingId,
    })

    // Send confirmation emails
    try {
      console.log("Calling sendBookingConfirmation...")
      console.log("SendGrid API Key configured:", !!process.env.SENDGRID_API_KEY)
      console.log("SendGrid API Key length:", process.env.SENDGRID_API_KEY?.length || 0)

      await sendBookingConfirmation(bookingData)
      console.log("✅ Confirmation emails sent successfully!")
    } catch (emailError) {
      console.error("❌ Failed to send confirmation email:", emailError)
      console.error("Email error details:", emailError instanceof Error ? emailError.message : emailError)
      console.error("Email error stack:", emailError instanceof Error ? emailError.stack : "No stack trace")
      // Continue with booking even if email fails
    }

    // In a real app, you'd save this to your database
    console.log("=== BOOKING COMPLETED ===")
    console.log("Booking created successfully:", bookingId)

    return NextResponse.json({
      success: true,
      bookingId,
      booking: bookingData,
    })
  } catch (error) {
    console.error("=== BOOKING API ERROR ===")
    console.error("Error creating booking:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to create booking",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
