import { type NextRequest, NextResponse } from "next/server"

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData()

    const file = formData.get("file") as File
    const documentType = formData.get("documentType") as string
    const bookingId = formData.get("bookingId") as string
    const customerName = formData.get("customerName") as string
    const customerEmail = formData.get("customerEmail") as string

    if (!file || !documentType) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Validate file
    const allowedTypes = ["application/pdf", "image/jpeg", "image/png"]
    if (!allowedTypes.includes(file.type)) {
      return NextResponse.json({ error: "Invalid file type. Please upload PDF, JPEG, or PNG files." }, { status: 400 })
    }

    if (file.size > 10 * 1024 * 1024) {
      // 10MB limit
      return NextResponse.json({ error: "File too large. Maximum size is 10MB." }, { status: 400 })
    }

    // Convert file to base64 for email attachment
    const fileBuffer = Buffer.from(await file.arrayBuffer())
    const base64File = fileBuffer.toString("base64")

    // Prepare email data - sending from contact@ to contact@
    const emailData = {
      personalizations: [
        {
          to: [{ email: "contact@onlinemarriagesnow.com" }],
          subject: `📄 New Document Upload: ${documentType} from ${customerName || "Customer"}`,
        },
      ],
      from: { email: "contact@onlinemarriagesnow.com", name: "OnlineMarriagesNow Document System" },
      content: [
        {
          type: "text/html",
          value: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2 style="color: #e11d48;">📄 New Document Upload</h2>
              <p>A customer has uploaded a new document through your website.</p>
              
              <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <h3 style="margin-top: 0; color: #334155;">Document Details:</h3>
                <ul style="list-style: none; padding: 0;">
                  <li style="margin: 8px 0;"><strong>Customer:</strong> ${customerName || "Not provided"}</li>
                  <li style="margin: 8px 0;"><strong>Email:</strong> ${customerEmail || "Not provided"}</li>
                  <li style="margin: 8px 0;"><strong>Booking ID:</strong> ${bookingId || "Not provided"}</li>
                  <li style="margin: 8px 0;"><strong>Document Type:</strong> ${documentType}</li>
                  <li style="margin: 8px 0;"><strong>File Name:</strong> ${file.name}</li>
                  <li style="margin: 8px 0;"><strong>File Size:</strong> ${(file.size / 1024).toFixed(1)} KB</li>
                  <li style="margin: 8px 0;"><strong>Uploaded:</strong> ${new Date().toLocaleString()}</li>
                </ul>
              </div>
              
              <p><strong>📎 The document is attached to this email.</strong></p>
              
              <div style="background: #fef3c7; padding: 15px; border-radius: 8px; margin: 20px 0;">
                <p style="margin: 0; color: #92400e;"><strong>💡 Tip:</strong> Save this document to your Google Drive or filing system for easy access during the ceremony process.</p>
              </div>
              
              <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e2e8f0; color: #64748b; font-size: 14px;">
                <p>This email was sent automatically from your OnlineMarriagesNow document upload system.</p>
              </div>
            </div>
          `,
        },
      ],
      attachments: [
        {
          content: base64File,
          filename: file.name,
          type: file.type,
          disposition: "attachment",
        },
      ],
    }

    // Send email using SendGrid API
    const response = await fetch("https://api.sendgrid.com/v3/mail/send", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.SENDGRID_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(emailData),
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error("SendGrid error:", errorText)
      throw new Error(`SendGrid API error: ${response.status}`)
    }

    return NextResponse.json({
      success: true,
      message: "Document uploaded and emailed successfully!",
    })
  } catch (error) {
    console.error("Document upload error:", error)
    return NextResponse.json(
      {
        error: "Failed to upload document. Please try again or contact support.",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
