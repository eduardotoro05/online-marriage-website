import { NextResponse } from "next/server"
import Stripe from "stripe"

export async function POST(req: Request) {
  try {
    const stripeSecretKey = process.env.STRIPE_SECRET_KEY

    if (!stripeSecretKey) {
      return NextResponse.json({ valid: false, error: "Payment system not configured" }, { status: 500 })
    }

    const stripe = new Stripe(stripeSecretKey, {
      apiVersion: "2023-10-16",
    })

    const body = await req.json()
    const { promoCode, amount } = body

    console.log("Validating promo code:", promoCode)
    console.log("Stripe key type:", stripeSecretKey.startsWith("sk_test_") ? "test" : "live")

    if (!promoCode) {
      return NextResponse.json({ valid: false, error: "Promo code is required" }, { status: 400 })
    }

    try {
      // Retrieve the promotion code from Stripe
      console.log("Searching for promotion code in Stripe...")
      const promotionCodes = await stripe.promotionCodes.list({
        code: promoCode,
        active: true,
        limit: 1,
      })

      console.log("Found promotion codes:", promotionCodes.data.length)

      if (promotionCodes.data.length === 0) {
        // Let's also try searching without the active filter
        const allPromotionCodes = await stripe.promotionCodes.list({
          code: promoCode,
          limit: 1,
        })

        console.log("Total promotion codes with this code (including inactive):", allPromotionCodes.data.length)

        if (allPromotionCodes.data.length > 0) {
          const inactiveCode = allPromotionCodes.data[0]
          console.log("Found inactive code:", {
            active: inactiveCode.active,
            coupon_valid: inactiveCode.coupon.valid,
            expires_at: inactiveCode.expires_at,
            max_redemptions: inactiveCode.max_redemptions,
            times_redeemed: inactiveCode.times_redeemed,
          })

          if (!inactiveCode.active) {
            return NextResponse.json({
              valid: false,
              error: "This promo code is not active",
            })
          }

          if (inactiveCode.expires_at && inactiveCode.expires_at < Math.floor(Date.now() / 1000)) {
            return NextResponse.json({
              valid: false,
              error: "This promo code has expired",
            })
          }
        }

        return NextResponse.json({
          valid: false,
          error: "Invalid or expired promo code",
        })
      }

      const promotionCode = promotionCodes.data[0]
      const coupon = promotionCode.coupon

      console.log("Promotion code details:", {
        id: promotionCode.id,
        active: promotionCode.active,
        coupon_id: coupon.id,
        coupon_valid: coupon.valid,
        percent_off: coupon.percent_off,
        amount_off: coupon.amount_off,
        times_redeemed: promotionCode.times_redeemed,
        max_redemptions: coupon.max_redemptions,
      })

      // Check if the coupon is active and not expired
      if (!coupon.valid) {
        return NextResponse.json({
          valid: false,
          error: "This promo code has expired",
        })
      }

      // Check usage limits
      if (coupon.max_redemptions && promotionCode.times_redeemed >= coupon.max_redemptions) {
        return NextResponse.json({
          valid: false,
          error: "This promo code has reached its usage limit",
        })
      }

      // Calculate discount
      let discountAmount = 0
      let discountType: "percentage" | "fixed" = "fixed"

      if (coupon.percent_off) {
        discountType = "percentage"
        discountAmount = coupon.percent_off
      } else if (coupon.amount_off) {
        discountType = "fixed"
        discountAmount = coupon.amount_off / 100 // Convert from cents to dollars
      }

      console.log("Discount calculated:", { discountAmount, discountType })

      return NextResponse.json({
        valid: true,
        discount: {
          amount: discountAmount,
          type: discountType,
        },
        promotionCodeId: promotionCode.id,
        couponId: coupon.id,
      })
    } catch (stripeError: any) {
      console.error("Stripe error:", stripeError)
      return NextResponse.json({
        valid: false,
        error: "Error connecting to payment system",
      })
    }
  } catch (error) {
    console.error("Error validating promo code:", error)
    return NextResponse.json({ valid: false, error: "Error validating promo code" }, { status: 500 })
  }
}
