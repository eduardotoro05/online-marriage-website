import { NextResponse } from "next/server"

export async function GET(req: Request, { params }: { params: { bookingId: string } }) {
  try {
    const { bookingId } = params

    // In a real app, you would fetch this from your database
    // For now, we'll return mock data based on the booking ID

    // Mock booking data - in production this would come from your database
    const mockBooking = {
      id: bookingId,
      status: "Confirmed",
      package: "Premium",
      ceremonyDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString(),
      ceremonyTime: "2:00 PM EST",
      partner1Name: "Partner 1",
      partner2Name: "Partner 2",
      partner1Email: "partner1@example.com",
      partner2Email: "partner2@example.com",
      totalAmount: 299,
      finalAmount: 0, // Free with promo code
      promoCode: "TESTER",
      discount: 299,
      zoomMeetingId: "123-456-789",
      zoomJoinUrl: "https://zoom.us/j/123456789",
      zoomPassword: "wedding123",
      createdAt: new Date().toISOString(),
    }

    return NextResponse.json(mockBooking)
  } catch (error) {
    console.error("Error fetching booking:", error)
    return NextResponse.json({ error: "Booking not found" }, { status: 404 })
  }
}
