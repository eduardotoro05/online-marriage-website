import { NextResponse } from "next/server"

export async function GET() {
  try {
    const apiToken = process.env.CALENDLY_API_TOKEN

    if (!apiToken) {
      return NextResponse.json({ error: "CALENDLY_API_TOKEN not configured" }, { status: 500 })
    }

    // Test API connection by getting user info
    const response = await fetch("https://api.calendly.com/users/me", {
      headers: {
        Authorization: apiToken,
        "Content-Type": "application/json",
      },
    })

    if (!response.ok) {
      const errorText = await response.text()
      return NextResponse.json(
        {
          error: "Calendly API error",
          status: response.status,
          message: errorText,
        },
        { status: response.status },
      )
    }

    const userData = await response.json()

    return NextResponse.json({
      success: true,
      message: "Calendly API connection successful!",
      user: {
        name: userData.resource.name,
        email: userData.resource.email,
        uri: userData.resource.uri,
      },
    })
  } catch (error) {
    console.error("Calendly API test error:", error)
    return NextResponse.json({ error: "Failed to test Calendly API" }, { status: 500 })
  }
}
