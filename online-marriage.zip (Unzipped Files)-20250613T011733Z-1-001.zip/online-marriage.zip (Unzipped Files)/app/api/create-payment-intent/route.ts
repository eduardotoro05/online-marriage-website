import { NextResponse } from "next/server"
import Stripe from "stripe"

export async function POST(req: Request) {
  try {
    // Check if Stripe secret key is available
    const stripeSecretKey = process.env.STRIPE_SECRET_KEY

    if (!stripeSecretKey) {
      console.error("STRIPE_SECRET_KEY environment variable is not set")
      return NextResponse.json(
        { error: "Payment processing is not configured. Please contact support." },
        { status: 500 },
      )
    }

    // Initialize Stripe with the secret key
    const stripe = new Stripe(stripeSecretKey, {
      apiVersion: "2023-10-16",
    })

    const body = await req.json()
    const { amount, metadata, promotionCodeId } = body

    // Validate amount
    if (!amount || amount < 0) {
      return NextResponse.json({ error: "Invalid amount provided" }, { status: 400 })
    }

    // If amount is 0 (free with promo code), don't create payment intent
    if (amount === 0) {
      return NextResponse.json({
        clientSecret: null,
        free: true,
        message: "No payment required",
      })
    }

    // Create payment intent options
    const paymentIntentOptions: Stripe.PaymentIntentCreateParams = {
      amount: Math.round(amount * 100), // Stripe expects amount in cents
      currency: "usd",
      metadata: metadata || {},
      automatic_payment_methods: {
        enabled: true,
      },
    }

    // Add promotion code if provided
    if (promotionCodeId) {
      paymentIntentOptions.metadata = {
        ...paymentIntentOptions.metadata,
        promotion_code_id: promotionCodeId,
      }
    }

    // Create a PaymentIntent with the specified amount
    const paymentIntent = await stripe.paymentIntents.create(paymentIntentOptions)

    // Return the client secret to the client
    return NextResponse.json({
      clientSecret: paymentIntent.client_secret,
      free: false,
    })
  } catch (error) {
    console.error("Error creating payment intent:", error)
    return NextResponse.json({ error: "Error creating payment intent" }, { status: 500 })
  }
}

// Add a GET handler for health check
export async function GET() {
  const hasStripeKey = !!process.env.STRIPE_SECRET_KEY

  return NextResponse.json({
    status: "Payment API is running",
    configured: hasStripeKey,
  })
}
