import { NextResponse } from "next/server"

// This endpoint will receive webhook events from Calendly
export async function POST(req: Request) {
  try {
    const body = await req.json()

    // Verify webhook signature (recommended for production)
    // const signature = req.headers.get('calendly-webhook-signature')
    // verifyWebhookSignature(signature, body, process.env.CALENDLY_WEBHOOK_SECRET)

    const { event, payload } = body

    // Handle different event types
    switch (event) {
      case "invitee.created": {
        // A new booking was created
        const { uri, email, name, event_type, scheduled_event } = payload

        // Extract ceremony details
        const ceremonyDetails = {
          calendlyEventUri: uri,
          customerEmail: email,
          customerName: name,
          eventType: event_type.name,
          startTime: scheduled_event.start_time,
          endTime: scheduled_event.end_time,
          location: scheduled_event.location,
          questions_and_answers: payload.questions_and_answers,
        }

        // Store in your database
        // await db.ceremonies.create(ceremonyDetails)

        // Create Zoom meeting for this ceremony
        // const zoomMeeting = await createZoomMeeting(ceremonyDetails)

        // Update ceremony with Zoom details
        // await db.ceremonies.update({
        //   where: { calendlyEventUri: uri },
        //   data: { zoomMeetingId: zoomMeeting.id, zoomJoinUrl: zoomMeeting.join_url }
        // })

        // Send confirmation emails with Zoom link
        // await sendConfirmationEmails(ceremonyDetails, zoomMeeting)

        console.log("New ceremony booked:", ceremonyDetails)
        break
      }

      case "invitee.canceled": {
        // Booking was canceled
        const { uri } = payload

        // Update status in database
        // await db.ceremonies.update({
        //   where: { calendlyEventUri: uri },
        //   data: { status: 'CANCELED' }
        // })

        // Cancel associated Zoom meeting
        // const ceremony = await db.ceremonies.findUnique({ where: { calendlyEventUri: uri } })
        // await cancelZoomMeeting(ceremony.zoomMeetingId)

        console.log("Ceremony canceled:", uri)
        break
      }

      case "invitee.rescheduled": {
        // Booking was rescheduled
        const { uri, scheduled_event } = payload

        // Update in database
        // await db.ceremonies.update({
        //   where: { calendlyEventUri: uri },
        //   data: {
        //     startTime: scheduled_event.start_time,
        //     endTime: scheduled_event.end_time
        //   }
        // })

        // Update Zoom meeting
        // const ceremony = await db.ceremonies.findUnique({ where: { calendlyEventUri: uri } })
        // await updateZoomMeeting(ceremony.zoomMeetingId, {
        //   start_time: scheduled_event.start_time
        // })

        console.log("Ceremony rescheduled:", uri)
        break
      }
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Calendly webhook error:", error)
    return NextResponse.json({ error: "Failed to process webhook" }, { status: 500 })
  }
}
