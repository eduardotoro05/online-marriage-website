import { NextResponse } from "next/server"

// Combined webhook handler for both Calendly and Zoom
export async function POST(req: Request) {
  try {
    // Determine which service sent the webhook
    const url = new URL(req.url)
    const path = url.pathname

    if (path.includes("/api/webhooks/calendly")) {
      return handleCalendlyWebhook(req)
    } else if (path.includes("/api/webhooks/zoom")) {
      return handleZoomWebhook(req)
    } else {
      return NextResponse.json({ error: "Unknown webhook source" }, { status: 400 })
    }
  } catch (error) {
    console.error("Webhook error:", error)
    return NextResponse.json({ error: "Failed to process webhook" }, { status: 500 })
  }
}

async function handleCalendlyWebhook(req: Request) {
  const body = await req.json()
  const { event, payload } = body

  switch (event) {
    case "invitee.created": {
      // Don't process immediately - wait for payment confirmation
      console.log("New Calendly booking created, waiting for payment...")
      break
    }

    case "invitee.canceled": {
      // Handle cancellation (could be auto-cancellation due to non-payment)
      console.log("Calendly booking cancelled:", payload.uri)
      break
    }
  }

  return NextResponse.json({ success: true })
}

async function handleZoomWebhook(req: Request) {
  const body = await req.json()

  // Verify webhook signature (recommended for production)
  // const signature = req.headers.get('x-zm-signature')
  // verifyZoomWebhookSignature(signature, body, process.env.ZOOM_WEBHOOK_SECRET)

  const { event, payload } = body

  switch (event) {
    case "meeting.started": {
      // Meeting has started
      // Update ceremony status
      break
    }

    case "meeting.ended": {
      // Meeting has ended
      // Update ceremony status
      break
    }

    case "recording.completed": {
      // Recording is available
      // Process and store recording
      break
    }
  }

  return NextResponse.json({ success: true })
}
