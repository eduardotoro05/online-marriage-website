import { NextResponse } from "next/server"
import sgMail from "@sendgrid/mail"

export async function GET(req: Request) {
  try {
    // Get test email from query params
    const { searchParams } = new URL(req.url)
    const testEmail = searchParams.get("email")

    if (!testEmail) {
      return NextResponse.json(
        { error: "No email provided. Use: /api/test-email?email=your@email.com" },
        { status: 400 },
      )
    }

    console.log("Testing email to:", testEmail)

    // Check if SendGrid API key is configured
    if (!process.env.SENDGRID_API_KEY) {
      console.log("ERROR: SendGrid API key not configured")
      return NextResponse.json({ error: "SendGrid API key not configured" }, { status: 500 })
    }

    console.log("SendGrid API key found:", process.env.SENDGRID_API_KEY.substring(0, 10) + "...")

    // Initialize SendGrid
    sgMail.setApiKey(process.env.SENDGRID_API_KEY)

    // Create a simple test email
    const msg = {
      to: testEmail,
      from: {
        email: "noreply@onlinemarriagesnow.com",
        name: "OnlineMarriagesNow",
      },
      subject: "Email Test from OnlineMarriagesNow",
      text: "This is a test email to verify your SendGrid integration is working.",
      html: `
        <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 600px; margin: 0 auto;">
          <h1 style="color: #ec4899;">Email Test Successful!</h1>
          <p>This is a test email to verify your SendGrid integration is working correctly.</p>
          <p>If you're seeing this, it means:</p>
          <ul>
            <li>Your SendGrid API key is valid</li>
            <li>Your sender email is verified</li>
            <li>The email delivery system is working</li>
          </ul>
          <p style="margin-top: 30px;">Timestamp: ${new Date().toISOString()}</p>
        </div>
      `,
    }

    // Send the test email
    console.log("Attempting to send test email...")
    const result = await sgMail.send(msg)
    console.log("Test email sent successfully:", result)

    return NextResponse.json({
      success: true,
      message: "Test email sent successfully. Please check your inbox (and spam folder).",
      sendGridResponse: result,
    })
  } catch (error) {
    console.error("Error sending test email:", error)

    // More detailed error logging
    if (error && typeof error === "object" && "response" in error) {
      console.error("SendGrid error response:", (error as any).response?.body)
    }

    return NextResponse.json(
      {
        success: false,
        error: "Failed to send test email",
        details: error instanceof Error ? error.message : "Unknown error",
        fullError: error,
      },
      { status: 500 },
    )
  }
}
