"use client"

import { Download, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { Document } from "@/lib/document-service"

interface DocumentDownloaderProps {
  documents: Document[]
}

export function DocumentDownloader({ documents }: DocumentDownloaderProps) {
  const handleDownload = (doc: Document) => {
    // In a real app, this would trigger a download from your storage
    // For now, we'll just open the URL
    if (doc.url) {
      window.open(doc.url, "_blank")
    }
  }

  return (
    <div className="space-y-6">
      <div className="rounded-lg border bg-blue-50 p-4">
        <div className="flex items-start gap-4">
          <FileText className="mt-0.5 h-5 w-5 text-blue-600" />
          <div>
            <h4 className="font-medium text-blue-800">Important Information</h4>
            <p className="text-sm text-blue-700">
              Download, print, and complete these forms. Once completed, scan and upload them in the "Upload Documents"
              tab.
            </p>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {documents.length === 0 ? (
          <p className="text-center py-8 text-muted-foreground">No documents available for download</p>
        ) : (
          documents.map((doc) => (
            <div key={doc.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center">
                <FileText className="h-5 w-5 mr-2 text-muted-foreground" />
                <div>
                  <p className="font-medium">{doc.name}</p>
                  <p className="text-sm text-muted-foreground">Required for marriage application</p>
                </div>
              </div>
              <Button variant="outline" size="sm" onClick={() => handleDownload(doc)}>
                <Download className="h-4 w-4 mr-1" />
                Download
              </Button>
            </div>
          ))
        )}
      </div>

      <div className="rounded-lg border bg-amber-50 p-4 mt-6">
        <h4 className="font-medium text-amber-800 mb-2">What You'll Need</h4>
        <ul className="list-disc pl-5 space-y-1 text-sm text-amber-700">
          <li>Government-issued photo ID for both parties</li>
          <li>Completed and signed Utah marriage application</li>
          <li>Social Security Numbers (for US citizens)</li>
          <li>Previous marriage information (if applicable)</li>
        </ul>
      </div>
    </div>
  )
}
