"use client"

import type React from "react"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { Elements, PaymentElement, useStripe, useElements } from "@stripe/react-stripe-js"
import { getStripe } from "@/lib/stripe-client"
import { Button } from "@/components/ui/button"
import { Loader2 } from "lucide-react"

interface PaymentFormProps {
  clientSecret: string
  bookingData: any
}

export function StripePaymentForm({ clientSecret, bookingData }: PaymentFormProps) {
  return (
    <Elements stripe={getStripe()} options={{ clientSecret }}>
      <PaymentFormContent bookingData={bookingData} />
    </Elements>
  )
}

function PaymentFormContent({ bookingData }: { bookingData: any }) {
  const stripe = useStripe()
  const elements = useElements()
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [errorMessage, setErrorMessage] = useState<string | undefined>()

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()

    if (!stripe || !elements) {
      return
    }

    setIsLoading(true)

    try {
      // Confirm the payment
      const { error, paymentIntent } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/booking/confirmation`,
        },
        redirect: "if_required",
      })

      if (error) {
        setErrorMessage(error.message)
        setIsLoading(false)
        return
      }

      if (paymentIntent && paymentIntent.status === "succeeded") {
        // Payment successful, book the ceremony
        const response = await fetch("/api/book-ceremony", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            ...bookingData,
            paymentIntentId: paymentIntent.id,
          }),
        })

        const data = await response.json()

        if (data.success) {
          // Redirect to confirmation page with booking details
          router.push(`/booking/confirmation?bookingId=${data.bookingId}`)
        } else {
          setErrorMessage("Error booking ceremony. Please contact support.")
        }
      }
    } catch (err) {
      console.error("Payment error:", err)
      setErrorMessage("An unexpected error occurred. Please try again.")
    }

    setIsLoading(false)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      {errorMessage && <div className="rounded-md bg-red-50 p-4 text-sm text-red-500">{errorMessage}</div>}
      <Button type="submit" disabled={!stripe || isLoading} className="w-full bg-rose-600 hover:bg-rose-700">
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Processing...
          </>
        ) : (
          "Complete Payment"
        )}
      </Button>
    </form>
  )
}
