"use client"

import { CheckCircle, Clock } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import type { ApplicationProcess } from "@/lib/document-service"

interface ApplicationTrackerProps {
  process: ApplicationProcess
}

export function ApplicationTracker({ process }: ApplicationTrackerProps) {
  const progressPercentage = (process.step / process.totalSteps) * 100

  // Define all steps in the process
  const steps = [
    { name: "Initial Booking & Eligibility", description: "Complete online booking and verify eligibility" },
    { name: "Marriage License Application", description: "Complete and submit Utah marriage license application" },
    { name: "Witness Coordination", description: "Identify and coordinate with your witnesses" },
    { name: "Pre-Ceremony Preparation", description: "Confirm license approval and test technology" },
    { name: "Wedding Ceremony", description: "Participate in your online wedding ceremony" },
    { name: "Post-Ceremony Processing", description: "Process marriage certificate request" },
    { name: "Certificate Delivery", description: "Receive your digital and physical marriage certificate" },
  ]

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium">Application Progress</p>
            <h3 className="text-2xl font-bold">{process.currentStepName}</h3>
          </div>
          <div className="text-right">
            <p className="text-sm font-medium">
              Step {process.step} of {process.totalSteps}
            </p>
            <p className="text-sm text-muted-foreground">{Math.round(progressPercentage)}% Complete</p>
          </div>
        </div>
        <Progress value={progressPercentage} className="h-2" />
      </div>

      {process.nextAction && (
        <div className="rounded-lg border bg-amber-50 p-4">
          <div className="flex items-start gap-4">
            <Clock className="mt-0.5 h-5 w-5 text-amber-600" />
            <div>
              <h4 className="font-medium text-amber-800">Next Action Required</h4>
              <p className="text-sm text-amber-700">{process.nextAction}</p>
            </div>
          </div>
        </div>
      )}

      <div className="space-y-4">
        <h3 className="font-medium">Process Timeline</h3>
        <div className="space-y-4">
          {steps.map((step, index) => {
            const isCompleted = index + 1 < process.step
            const isCurrent = index + 1 === process.step

            return (
              <div
                key={index}
                className={`flex items-start gap-4 p-3 rounded-lg border ${
                  isCurrent ? "bg-blue-50 border-blue-200" : isCompleted ? "bg-green-50 border-green-200" : "bg-gray-50"
                }`}
              >
                <div
                  className={`rounded-full p-1 ${
                    isCompleted
                      ? "bg-green-100 text-green-600"
                      : isCurrent
                        ? "bg-blue-100 text-blue-600"
                        : "bg-gray-200"
                  }`}
                >
                  {isCompleted ? (
                    <CheckCircle className="h-5 w-5" />
                  ) : (
                    <div className="flex h-5 w-5 items-center justify-center rounded-full bg-white text-xs font-medium">
                      {index + 1}
                    </div>
                  )}
                </div>
                <div>
                  <p className={`font-medium ${isCurrent ? "text-blue-800" : isCompleted ? "text-green-800" : ""}`}>
                    {step.name}
                  </p>
                  <p className="text-sm text-muted-foreground">{step.description}</p>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
