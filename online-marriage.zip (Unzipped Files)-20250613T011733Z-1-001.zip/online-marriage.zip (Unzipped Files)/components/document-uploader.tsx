"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Upload, X, FileText, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { type Document, uploadDocument } from "@/lib/document-service"

interface DocumentUploaderProps {
  onDocumentUploaded: (document: Document) => void
}

export function DocumentUploader({ onDocumentUploaded }: DocumentUploaderProps) {
  const [dragActive, setDragActive] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [uploadSuccess, setUploadSuccess] = useState(false)
  const [uploadError, setUploadError] = useState<string | null>(null)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [documentType, setDocumentType] = useState<Document["type"]>("id")

  const inputRef = useRef<HTMLInputElement>(null)

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()

    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0])
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault()

    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0])
    }
  }

  const handleFile = (file: File) => {
    // Check file type
    const allowedTypes = ["application/pdf", "image/jpeg", "image/png"]
    if (!allowedTypes.includes(file.type)) {
      setUploadError("Please upload a PDF, JPEG, or PNG file")
      return
    }

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setUploadError("File size must be less than 5MB")
      return
    }

    setSelectedFile(file)
    setUploadError(null)
  }

  const handleUpload = async () => {
    if (!selectedFile) return

    setUploading(true)
    setUploadError(null)

    try {
      // In a real app, this would upload to your storage solution
      const uploadedDoc = await uploadDocument(selectedFile, documentType, "user-1")

      setUploadSuccess(true)
      onDocumentUploaded(uploadedDoc)

      // Reset after 3 seconds
      setTimeout(() => {
        setSelectedFile(null)
        setUploadSuccess(false)
      }, 3000)
    } catch (error) {
      console.error("Upload error:", error)
      setUploadError("Failed to upload document. Please try again.")
    } finally {
      setUploading(false)
    }
  }

  const openFileSelector = () => {
    if (inputRef.current) {
      inputRef.current.click()
    }
  }

  const cancelSelection = () => {
    setSelectedFile(null)
    setUploadError(null)
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Document Type</label>
          <select
            className="w-full rounded-md border border-input bg-background px-3 py-2"
            value={documentType}
            onChange={(e) => setDocumentType(e.target.value as Document["type"])}
          >
            <option value="id">Government ID</option>
            <option value="application">Signed Application</option>
            <option value="other">Other Document</option>
          </select>
        </div>
      </div>

      <div
        className={`border-2 border-dashed rounded-lg p-6 text-center ${
          dragActive ? "border-blue-500 bg-blue-50" : "border-gray-300"
        } ${selectedFile ? "bg-gray-50" : ""}`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <input ref={inputRef} type="file" className="hidden" onChange={handleChange} accept=".pdf,.jpg,.jpeg,.png" />

        {selectedFile ? (
          <div className="space-y-4">
            <div className="flex items-center justify-center">
              <FileText className="h-8 w-8 text-blue-500" />
            </div>
            <div>
              <p className="font-medium">{selectedFile.name}</p>
              <p className="text-sm text-muted-foreground">{(selectedFile.size / 1024 / 1024).toFixed(2)} MB</p>
            </div>
            <div className="flex justify-center space-x-2">
              {uploadSuccess ? (
                <Button variant="ghost" className="bg-green-50 text-green-700" disabled>
                  <Check className="h-4 w-4 mr-1" />
                  Uploaded Successfully
                </Button>
              ) : (
                <>
                  <Button
                    variant="default"
                    onClick={handleUpload}
                    disabled={uploading}
                    className="bg-rose-600 hover:bg-rose-700"
                  >
                    {uploading ? (
                      <>
                        <div className="h-4 w-4 mr-2 animate-spin rounded-full border-2 border-t-transparent" />
                        Uploading...
                      </>
                    ) : (
                      <>
                        <Upload className="h-4 w-4 mr-1" />
                        Upload File
                      </>
                    )}
                  </Button>
                  <Button variant="outline" onClick={cancelSelection} disabled={uploading}>
                    <X className="h-4 w-4 mr-1" />
                    Cancel
                  </Button>
                </>
              )}
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-center">
              <Upload className="h-10 w-10 text-gray-400" />
            </div>
            <div>
              <p className="font-medium">Drag and drop your file here</p>
              <p className="text-sm text-muted-foreground">or click to browse (PDF, JPEG, PNG up to 5MB)</p>
            </div>
            <Button variant="outline" onClick={openFileSelector}>
              Select File
            </Button>
          </div>
        )}
      </div>

      {uploadError && <div className="rounded-lg bg-red-50 p-3 text-red-700 text-sm">{uploadError}</div>}

      <div className="rounded-lg border bg-blue-50 p-4">
        <h4 className="font-medium text-blue-800 mb-2">Document Requirements</h4>
        <ul className="list-disc pl-5 space-y-1 text-sm text-blue-700">
          <li>Government IDs must be valid and not expired</li>
          <li>All text must be clearly legible</li>
          <li>Applications must be completely filled out and signed</li>
          <li>Documents must be in PDF, JPEG, or PNG format</li>
          <li>Maximum file size is 5MB per document</li>
        </ul>
      </div>
    </div>
  )
}
