"use client"

import { useEffect, useRef, useState } from "react"

interface CalendlyEmbedProps {
  url: string
  prefill?: {
    name?: string
    email?: string
    customAnswers?: Record<string, string>
  }
  className?: string
  onEventScheduled?: (eventData: any) => void
}

export function CalendlyEmbed({ url, prefill, className, onEventScheduled }: CalendlyEmbedProps) {
  const [isLoading, setIsLoading] = useState(true)
  const iframeRef = useRef<HTMLIFrameElement>(null)

  useEffect(() => {
    // Listen for Calendly events
    const handleMessage = (event: MessageEvent) => {
      if (event.origin !== "https://calendly.com") return

      if (event.data.event && event.data.event === "calendly.event_scheduled") {
        console.log("Event scheduled:", event.data.payload)
        if (onEventScheduled) {
          onEventScheduled(event.data.payload)
        }
      }
    }

    window.addEventListener("message", handleMessage)
    return () => window.removeEventListener("message", handleMessage)
  }, [onEventScheduled])

  // Build the iframe URL with parameters to hide elements and prefill data
  const buildIframeUrl = () => {
    const iframeUrl = new URL(url)
    iframeUrl.searchParams.set("embed_domain", window.location.hostname)
    iframeUrl.searchParams.set("embed_type", "Inline")
    iframeUrl.searchParams.set("hide_gdpr_banner", "1")
    iframeUrl.searchParams.set("background_color", "f8fafc") // Match your site's background
    iframeUrl.searchParams.set("text_color", "1e293b") // Match your site's text color
    iframeUrl.searchParams.set("primary_color", "e11d48") // Rose-600 color

    // Add prefill data if available
    if (prefill?.name) {
      iframeUrl.searchParams.set("name", prefill.name)
    }

    if (prefill?.email) {
      iframeUrl.searchParams.set("email", prefill.email)
    }

    // Add any custom answers
    if (prefill?.customAnswers) {
      Object.entries(prefill.customAnswers).forEach(([key, value]) => {
        iframeUrl.searchParams.set(key, value)
      })
    }

    return iframeUrl.toString()
  }

  const handleIframeLoad = () => {
    setIsLoading(false)
  }

  return (
    <div className={`relative w-full ${className || ""}`}>
      {isLoading && (
        <div className="flex items-center justify-center h-[600px] bg-gray-50 rounded-lg border">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-rose-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Loading calendar...</p>
          </div>
        </div>
      )}

      <iframe
        ref={iframeRef}
        src={buildIframeUrl()}
        width="100%"
        height="700"
        frameBorder="0"
        scrolling="no"
        onLoad={handleIframeLoad}
        className="w-full min-h-[700px] rounded-lg border border-gray-200"
        style={{
          width: "100%",
          height: "700px",
          minHeight: "700px",
          border: "1px solid #e5e7eb",
          borderRadius: "8px",
        }}
        title="Select Your Ceremony Date & Time"
      />
    </div>
  )
}
