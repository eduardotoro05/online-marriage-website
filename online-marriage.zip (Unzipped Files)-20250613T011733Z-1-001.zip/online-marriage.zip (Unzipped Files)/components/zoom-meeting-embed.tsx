"use client"

import { useEffect, useRef, useState } from "react"

interface ZoomMeetingEmbedProps {
  meetingNumber: string
  passWord: string
  userName: string
  userEmail: string
  role?: number // 0 for attendee, 1 for host
  leaveUrl: string
  className?: string
}

export function ZoomMeetingEmbed({
  meetingNumber,
  passWord,
  userName,
  userEmail,
  role = 0,
  leaveUrl,
  className = "min-h-[600px] w-full",
}: ZoomMeetingEmbedProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [signature, setSignature] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    // Get signature from server
    const getSignature = async () => {
      try {
        const response = await fetch("/api/zoom/generate-signature", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ meetingNumber, role }),
        })

        if (!response.ok) {
          throw new Error("Failed to get signature")
        }

        const data = await response.json()
        setSignature(data.signature)
        setIsLoading(false)
      } catch (err) {
        console.error("Error getting signature:", err)
        setError("Failed to initialize Zoom meeting")
        setIsLoading(false)
      }
    }

    getSignature()
  }, [meetingNumber, role])

  useEffect(() => {
    // Only proceed if we have the signature
    if (!signature || isLoading) return

    // Load the Zoom Web SDK
    const loadZoomSdk = async () => {
      if (document.getElementById("zoom-sdk-script")) {
        initializeZoomMeeting()
        return
      }

      const script = document.createElement("script")
      script.id = "zoom-sdk-script"
      script.src = "https://source.zoom.us/2.13.0/lib/vendor/react.min.js"
      script.async = true
      document.body.appendChild(script)

      const script2 = document.createElement("script")
      script2.src = "https://source.zoom.us/2.13.0/lib/vendor/react-dom.min.js"
      script2.async = true
      document.body.appendChild(script2)

      const script3 = document.createElement("script")
      script3.src = "https://source.zoom.us/2.13.0/lib/vendor/redux.min.js"
      script3.async = true
      document.body.appendChild(script3)

      const script4 = document.createElement("script")
      script4.src = "https://source.zoom.us/2.13.0/lib/vendor/redux-thunk.min.js"
      script4.async = true
      document.body.appendChild(script4)

      const script5 = document.createElement("script")
      script5.src = "https://source.zoom.us/2.13.0/zoom-meeting-2.13.0.min.js"
      script5.async = true
      script5.onload = initializeZoomMeeting
      document.body.appendChild(script5)
    }

    // Initialize the Zoom meeting
    const initializeZoomMeeting = async () => {
      if (!window.ZoomMtg) {
        console.error("Zoom Meeting SDK not loaded")
        return
      }

      // Initialize Zoom Meeting SDK
      window.ZoomMtg.setZoomJSLib("https://source.zoom.us/2.13.0/lib", "/av")
      window.ZoomMtg.preLoadWasm()
      window.ZoomMtg.prepareWebSDK()

      // Get the SDK key from server
      const response = await fetch("/api/zoom/get-sdk-key")
      const { sdkKey } = await response.json()

      // Join the meeting
      window.ZoomMtg.init({
        leaveUrl,
        success: () => {
          window.ZoomMtg.join({
            meetingNumber,
            userName,
            signature,
            sdkKey,
            userEmail,
            passWord,
            success: () => {
              console.log("Joined Zoom meeting successfully")
            },
            error: (error: any) => {
              console.error("Failed to join Zoom meeting", error)
              setError("Failed to join Zoom meeting")
            },
          })
        },
        error: (error: any) => {
          console.error("Failed to initialize Zoom", error)
          setError("Failed to initialize Zoom")
        },
      })
    }

    loadZoomSdk()

    // Cleanup function
    return () => {
      // Clean up Zoom meeting if needed
      if (window.ZoomMtg) {
        window.ZoomMtg.leaveMeeting({})
      }
    }
  }, [signature, isLoading, meetingNumber, passWord, userName, userEmail, leaveUrl])

  if (isLoading) {
    return (
      <div className={`${className} flex items-center justify-center`}>
        <div className="text-center">
          <div className="h-12 w-12 animate-spin rounded-full border-4 border-rose-200 border-t-rose-600 mx-auto"></div>
          <p className="mt-4">Loading Zoom meeting...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className={`${className} flex items-center justify-center`}>
        <div className="text-center">
          <p className="text-red-500">{error}</p>
          <button
            onClick={() => window.location.reload()}
            className="mt-4 rounded-md bg-rose-600 px-4 py-2 text-white hover:bg-rose-700"
          >
            Try Again
          </button>
        </div>
      </div>
    )
  }

  return <div ref={containerRef} id="zoom-meeting-container" className={className} />
}

// Add TypeScript definitions for Zoom
declare global {
  interface Window {
    ZoomMtg: {
      setZoomJSLib: (path: string, dir: string) => void
      preLoadWasm: () => void
      prepareWebSDK: () => void
      init: (config: any) => void
      join: (config: any) => void
      leaveMeeting: (config: any) => void
    }
  }
}
