"use client"

import { useState, useEffect } from "react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Clock, AlertTriangle } from "lucide-react"

interface PaymentCountdownProps {
  expiresAt: Date
  onExpired: () => void
}

export function PaymentCountdown({ expiresAt, onExpired }: PaymentCountdownProps) {
  const [timeLeft, setTimeLeft] = useState<number>(0)
  const [isExpired, setIsExpired] = useState(false)

  useEffect(() => {
    const updateTimer = () => {
      const now = new Date().getTime()
      const expiry = expiresAt.getTime()
      const remaining = expiry - now

      if (remaining <= 0) {
        setTimeLeft(0)
        setIsExpired(true)
        onExpired()
      } else {
        setTimeLeft(remaining)
      }
    }

    // Update immediately
    updateTimer()

    // Update every second
    const interval = setInterval(updateTimer, 1000)

    return () => clearInterval(interval)
  }, [expiresAt, onExpired])

  const formatTime = (milliseconds: number) => {
    const minutes = Math.floor(milliseconds / (1000 * 60))
    const seconds = Math.floor((milliseconds % (1000 * 60)) / 1000)
    return `${minutes}:${seconds.toString().padStart(2, "0")}`
  }

  if (isExpired) {
    return (
      <Alert variant="destructive" className="mb-6">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          <strong>Booking Expired</strong> - Your ceremony slot has been released. Please start over to book a new time.
        </AlertDescription>
      </Alert>
    )
  }

  const isUrgent = timeLeft < 5 * 60 * 1000 // Less than 5 minutes

  return (
    <Alert variant={isUrgent ? "destructive" : "default"} className="mb-6">
      <Clock className="h-4 w-4" />
      <AlertDescription>
        <strong>Complete payment within {formatTime(timeLeft)}</strong> to secure your ceremony slot.
        {isUrgent && " Your booking will expire soon!"}
      </AlertDescription>
    </Alert>
  )
}
