"use client"

import { FileText, Download } from "lucide-react"
import { Button } from "@/components/ui/button"
import { SimpleDocumentService } from "@/lib/simple-document-service"

export function SimpleDocumentDownloader() {
  const documents = SimpleDocumentService.getDownloadableDocuments()

  return (
    <div className="space-y-4">
      {documents.map((doc) => (
        <div key={doc.id} className="flex items-center justify-between p-4 border rounded-lg">
          <div className="flex items-center">
            <FileText className="h-5 w-5 mr-3 text-blue-500" />
            <div>
              <p className="font-medium">{doc.name}</p>
              <p className="text-sm text-muted-foreground">{doc.description}</p>
            </div>
          </div>
          <Button variant="outline" asChild>
            <a href={doc.url} download>
              <Download className="h-4 w-4 mr-1" />
              Download
            </a>
          </Button>
        </div>
      ))}
    </div>
  )
}
